"""
snn_encoder.py
──────────────
Full Spiking Neural Network (SNN) Encoder.

Architecture:
  Input EEG  (batch, 23 channels, 1280 samples)
      ↓  Poisson rate encoder
  Spike trains  (batch, 23 channels, 1280 steps)
      ↓  LIF Layer 1: 256 neurons  + WTA
      ↓  LIF Layer 2: 128 neurons  + WTA
      ↓  LIF Layer 3: 64 neurons   + WTA
      ↓  Spike density temporal pooling
  Feature vector  (batch, 64)
"""

import torch
import torch.nn as nn
from torch import Tensor
from typing import List, Optional

from src.models.lif_neuron import LIFLayer, PoissonEncoder, winner_take_all


class SNNEncoder(nn.Module):
    """
    Multi-layer SNN encoder with LIF neurons and surrogate gradient training.

    Parameters
    ----------
    in_channels    : int    Input EEG channels (default 23).
    hidden_sizes   : list   Neuron counts per LIF layer (default [256, 128, 64]).
    out_dim        : int    Output feature dimension (default 64).
    tau_m_ms       : float  LIF membrane time constant (ms).
    dt_ms          : float  Simulation time step (ms).
    v_threshold    : float  Normalised firing threshold.
    v_reset        : float  Normalised reset potential.
    beta_sg        : float  Surrogate gradient sharpness.
    r_max          : float  Max Poisson firing rate (Hz).
    wta_k          : int    Winner-take-all top-k.
    dropout        : float  Dropout rate (default 0.3).
    """

    def __init__(
        self,
        in_channels  : int   = 23,
        hidden_sizes : List  = None,
        out_dim      : int   = 64,
        tau_m_ms     : float = 20.0,
        dt_ms        : float = 1.0,
        v_threshold  : float = 1.0,
        v_reset      : float = 0.0,
        beta_sg      : float = 10.0,
        r_max        : float = 100.0,
        wta_k        : int   = 10,
        dropout      : float = 0.3,
    ):
        super().__init__()

        if hidden_sizes is None:
            hidden_sizes = [256, 128, 64]

        self.in_channels   = in_channels
        self.hidden_sizes  = hidden_sizes
        self.out_dim       = out_dim
        self.wta_k         = wta_k

        # Poisson encoder
        self.encoder = PoissonEncoder(r_max=r_max, dt_ms=dt_ms)

        # Input projection: flatten channels → first LIF layer input
        self.input_proj = nn.Linear(in_channels, hidden_sizes[0])

        # LIF layers
        lif_kwargs = dict(
            tau_m_ms=tau_m_ms, dt_ms=dt_ms,
            v_threshold=v_threshold, v_reset=v_reset,
            beta_sg=beta_sg,
        )
        sizes = [hidden_sizes[0]] + hidden_sizes
        self.lif_layers = nn.ModuleList([
            LIFLayer(sizes[i], sizes[i + 1], **lif_kwargs)
            for i in range(len(hidden_sizes))
        ])

        # Dropout
        self.dropout = nn.Dropout(p=dropout)

        # Output projection to final embedding
        self.output_proj = nn.Linear(hidden_sizes[-1], out_dim)
        self.layer_norm  = nn.LayerNorm(out_dim)

        self._count_parameters()

    def forward(self, x: Tensor) -> Tensor:
        """
        Parameters
        ----------
        x : Tensor  Shape (batch, n_channels, n_samples).

        Returns
        -------
        features : Tensor  Shape (batch, out_dim) — spike-density embedding.
        """
        B, C, T = x.shape

        # 1. Poisson rate encoding → spike trains (B, C, T)
        spikes = self.encoder(x)

        # 2. Temporal simulation: process each time step
        n_steps   = spikes.shape[-1]
        membranes = [None] * len(self.lif_layers)

        # Accumulate spike counts across time for density estimation
        spike_accum = torch.zeros(
            B, self.hidden_sizes[-1], device=x.device
        )

        for t in range(n_steps):
            # Current input: (B, C)
            x_t = spikes[:, :, t]

            # Input projection
            h_t = self.input_proj(x_t)

            # Forward through LIF layers
            for i, lif in enumerate(self.lif_layers):
                h_t, membranes[i] = lif(h_t, membranes[i])
                # WTA lateral inhibition
                h_t = winner_take_all(h_t, self.wta_k)

            # Accumulate spike density
            spike_accum += h_t

        # 3. Temporal average pooling → spike density
        density = spike_accum / (n_steps + 1e-8)   # (B, hidden[-1])

        # 4. Dropout + projection + normalisation
        features = self.dropout(density)
        features = self.output_proj(features)
        features = self.layer_norm(features)

        return features

    def encode_rate(self, x: Tensor) -> Tensor:
        """
        Efficient rate-coded forward pass for inference:
        uses mean firing rate directly instead of step-by-step simulation.
        """
        B, C, T = x.shape
        # Convert signal energy to firing rate
        rates    = torch.abs(x).mean(dim=-1)         # (B, C)
        h        = self.input_proj(rates)
        for lif in self.lif_layers:
            # Steady-state approximation
            h = torch.sigmoid(lif.linear(h))
            h = winner_take_all(h, self.wta_k)
        h = self.dropout(h)
        return self.layer_norm(self.output_proj(h))

    def compute_energy(self, x: Tensor) -> float:
        """
        Estimate inference energy in millijoules (Loihi 2 model).

        Assumes 8.6 pJ per synaptic operation (SynOp).
        SynOps ≈ total spikes × fan-in of each receiving layer.
        """
        ENERGY_PER_SYNOP_PJ = 8.6
        B, C, T = x.shape
        spikes  = self.encoder(x)

        total_synops = 0
        n_steps = spikes.shape[-1]
        membranes = [None] * len(self.lif_layers)

        for t in range(n_steps):
            x_t = spikes[:, :, t]
            h_t = self.input_proj(x_t)
            for i, lif in enumerate(self.lif_layers):
                n_active = (h_t > 0).float().sum().item()
                fan_in   = lif.in_features
                total_synops += n_active * fan_in
                h_t, membranes[i] = lif(h_t, membranes[i])
                h_t = winner_take_all(h_t, self.wta_k)

        energy_pj = total_synops * ENERGY_PER_SYNOP_PJ
        energy_mj = energy_pj * 1e-9
        return energy_mj / B   # per sample

    def _count_parameters(self):
        total = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"SNNEncoder: {total:,} trainable parameters")
