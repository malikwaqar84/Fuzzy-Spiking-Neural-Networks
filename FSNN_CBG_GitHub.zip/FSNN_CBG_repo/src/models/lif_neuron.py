"""
lif_neuron.py
─────────────
Leaky Integrate-and-Fire (LIF) neuron implementation in PyTorch.

Implements:
  - LIF membrane dynamics (Eq. 1 from paper)
  - Surrogate gradient via fast sigmoid (Eq. 2 from paper)
  - Winner-Take-All (WTA) lateral inhibition
  - Poisson rate encoding for input conversion

Reference:
  Zenke & Ganguli, "SuperSpike", Neural Computation 2018.
  Gerstner et al., "Neuronal Dynamics", Cambridge 2014.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


# ── Surrogate gradient function ─────────────────────────────────────────────

class SurrogateSpike(torch.autograd.Function):
    """
    Heaviside step function for the forward pass;
    fast sigmoid derivative for the backward pass (surrogate gradient).

    Forward:  spike = 1  if V >= V_threshold  else 0
    Backward: dL/dV ≈ beta / (1 + beta|V - V_th|)^2
    """

    @staticmethod
    def forward(ctx, membrane: Tensor, threshold: float, beta: float) -> Tensor:
        ctx.save_for_backward(membrane)
        ctx.threshold = threshold
        ctx.beta      = beta
        return (membrane >= threshold).float()

    @staticmethod
    def backward(ctx, grad_output: Tensor):
        (membrane,) = ctx.saved_tensors
        beta        = ctx.beta
        threshold   = ctx.threshold
        # Fast sigmoid surrogate: 1 / (beta * |V - Vth| + 1)^2
        surrogate   = beta / (1.0 + beta * torch.abs(membrane - threshold)) ** 2
        grad_input  = grad_output * surrogate
        return grad_input, None, None


def surrogate_spike(membrane: Tensor, threshold: float = -0.055,
                    beta: float = 10.0) -> Tensor:
    """Convenience wrapper around SurrogateSpike."""
    return SurrogateSpike.apply(membrane, threshold, beta)


# ── LIF Neuron Layer ────────────────────────────────────────────────────────

class LIFLayer(nn.Module):
    """
    A fully-connected LIF neuron layer.

    Implements the discrete-time LIF recurrence:
      V[t] = alpha * V[t-1] * (1 - spike[t-1]) + W * x[t]
      spike[t] = Heaviside(V[t] - V_th)   [surrogate gradient in backward]

    where alpha = exp(-dt / tau_m) is the membrane decay factor.

    Parameters
    ----------
    in_features  : int    Number of input neurons / features.
    out_features : int    Number of LIF neurons in this layer.
    tau_m_ms     : float  Membrane time constant (ms, default 20).
    dt_ms        : float  Simulation time step (ms, default 1.0).
    v_threshold  : float  Normalised firing threshold (default 1.0).
    v_reset      : float  Normalised reset potential (default 0.0).
    beta_sg      : float  Surrogate gradient sharpness (default 10.0).
    bias         : bool   Use bias in the linear layer (default True).
    """

    def __init__(
        self,
        in_features  : int,
        out_features : int,
        tau_m_ms     : float = 20.0,
        dt_ms        : float = 1.0,
        v_threshold  : float = 1.0,
        v_reset      : float = 0.0,
        beta_sg      : float = 10.0,
        bias         : bool  = True,
    ):
        super().__init__()

        self.in_features  = in_features
        self.out_features = out_features
        self.v_threshold  = v_threshold
        self.v_reset      = v_reset
        self.beta_sg      = beta_sg

        # Membrane decay factor
        self.alpha = float(torch.exp(torch.tensor(-dt_ms / tau_m_ms)))

        # Synaptic weight matrix
        self.linear = nn.Linear(in_features, out_features, bias=bias)

        # Batch normalisation on pre-synaptic input
        self.bn = nn.BatchNorm1d(out_features)

        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.linear.weight)
        if self.linear.bias is not None:
            nn.init.zeros_(self.linear.bias)

    def forward(
        self,
        x         : Tensor,
        membrane  : Tensor = None,
    ):
        """
        Simulate one time step of LIF dynamics.

        Parameters
        ----------
        x        : Tensor  Shape (batch, in_features) — input at time t.
        membrane : Tensor  Shape (batch, out_features) — V[t-1].
                           Initialised to v_reset if None.

        Returns
        -------
        spike    : Tensor  Shape (batch, out_features) — spike train {0,1}.
        membrane : Tensor  Shape (batch, out_features) — updated membrane V[t].
        """
        batch_size = x.shape[0]

        if membrane is None:
            membrane = torch.full(
                (batch_size, self.out_features),
                self.v_reset,
                device=x.device, dtype=x.dtype
            )

        # Synaptic input
        i_syn = self.bn(self.linear(x))

        # Membrane update: leaky integration + synaptic drive
        membrane = self.alpha * membrane + i_syn

        # Spike detection (surrogate gradient in backward)
        spike = SurrogateSpike.apply(membrane, self.v_threshold, self.beta_sg)

        # Soft reset: subtract threshold on spike
        membrane = membrane - spike * (self.v_threshold - self.v_reset)

        return spike, membrane

    def init_membrane(self, batch_size: int, device: torch.device) -> Tensor:
        """Return a zero-initialised membrane tensor."""
        return torch.full(
            (batch_size, self.out_features),
            self.v_reset, device=device
        )


# ── Poisson Rate Encoder ─────────────────────────────────────────────────────

class PoissonEncoder(nn.Module):
    """
    Converts normalised EEG amplitudes to Poisson spike trains.

    For each input value x ∈ [0, 1], generates a Bernoulli sample
    at each time step with probability p = |x| * r_max * dt.

    Parameters
    ----------
    n_steps  : int    Number of simulation time steps.
    r_max    : float  Maximum firing rate in Hz (default 100).
    dt_ms    : float  Time step in ms (default 1.0).
    """

    def __init__(
        self,
        n_steps : int   = 1280,
        r_max   : float = 100.0,
        dt_ms   : float = 1.0,
    ):
        super().__init__()
        self.n_steps = n_steps
        self.prob_scale = r_max * dt_ms / 1000.0   # Hz × ms → probability

    def forward(self, x: Tensor) -> Tensor:
        """
        Parameters
        ----------
        x : Tensor  Shape (batch, channels, n_samples).
                    Values should be normalised to [-1, 1].

        Returns
        -------
        spikes : Tensor  Shape (n_steps, batch, channels), dtype float.
        """
        # Convert to firing probability
        prob   = torch.clamp(torch.abs(x) * self.prob_scale, 0.0, 1.0)

        # Generate Poisson spikes: Bernoulli sample per time step
        # Reshape x to (batch*channels, n_samples) for efficient sampling
        B, C, T = prob.shape
        steps   = min(self.n_steps, T)
        prob_t  = prob[:, :, :steps].reshape(B * C, steps)   # (B*C, T)

        spikes  = torch.bernoulli(prob_t)                      # {0,1}
        spikes  = spikes.reshape(B, C, steps)                  # (B, C, T)
        return spikes


# ── Winner-Take-All Inhibition ────────────────────────────────────────────────

def winner_take_all(spikes: Tensor, k: int = 10) -> Tensor:
    """
    Apply Winner-Take-All lateral inhibition to a spike tensor.
    Only the top-k most active neurons survive at each time step.

    Parameters
    ----------
    spikes : Tensor  Shape (batch, n_neurons) — spike rates or counts.
    k      : int     Number of winners to retain (default 10).

    Returns
    -------
    Tensor  Same shape, with all but top-k neurons set to zero.
    """
    if k >= spikes.shape[-1]:
        return spikes

    topk_vals, topk_idx = torch.topk(spikes, k=k, dim=-1)
    mask   = torch.zeros_like(spikes)
    mask.scatter_(-1, topk_idx, 1.0)
    return spikes * mask
