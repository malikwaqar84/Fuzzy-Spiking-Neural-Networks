"""
stgcn.py
────────
Spatio-Temporal Graph Convolutional Network (STGCN).

Processes dynamic brain graph sequences:
  Input : (batch, T_graphs, N_nodes, F_features)
  Output: (batch, 32) — graph embedding f_Graph

Architecture per time step:
  GCN Layer 1 (64 dim) → ReLU → Dropout
  GCN Layer 2 (32 dim) → ReLU → Dropout
  Temporal Gated Convolution (kernel=3)
  Global Mean Pooling

Reference:
  Kipf & Welling, "Semi-supervised classification with GCNs", ICLR 2017.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import List, Optional


class GraphConvLayer(nn.Module):
    """
    Single spectral GCN layer:
      H^{(l+1)} = σ( D̃^{-1/2} Ã D̃^{-1/2} H^{(l)} W^{(l)} )

    Parameters
    ----------
    in_features  : int  Input node feature dimension.
    out_features : int  Output node feature dimension.
    bias         : bool Use bias (default True).
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.weight = nn.Parameter(
            torch.FloatTensor(in_features, out_features)
        )
        self.bias = nn.Parameter(torch.FloatTensor(out_features)) if bias else None
        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x: Tensor, adj_norm: Tensor) -> Tensor:
        """
        Parameters
        ----------
        x        : Tensor  (batch, N, F_in) — node features.
        adj_norm : Tensor  (batch, N, N) or (N, N) — normalised adjacency.

        Returns
        -------
        Tensor  (batch, N, F_out)
        """
        # Support + weight projection
        support = torch.matmul(x, self.weight)               # (B, N, F_out)

        # Graph convolution: Ã_norm × support
        if adj_norm.dim() == 2:
            adj_norm = adj_norm.unsqueeze(0).expand(x.size(0), -1, -1)

        out = torch.bmm(adj_norm, support)                   # (B, N, F_out)

        if self.bias is not None:
            out = out + self.bias

        return out


class TemporalConvBlock(nn.Module):
    """
    Gated temporal convolution block applied to graph embeddings over time.

    Parameters
    ----------
    in_channels  : int  Input channel dimension.
    out_channels : int  Output channel dimension.
    kernel_size  : int  Temporal convolution kernel (default 3).
    """

    def __init__(
        self,
        in_channels  : int,
        out_channels : int,
        kernel_size  : int = 3,
    ):
        super().__init__()
        # Padding to preserve temporal dimension
        pad = (kernel_size - 1) // 2
        self.conv    = nn.Conv1d(in_channels, out_channels * 2,
                                  kernel_size=kernel_size, padding=pad)
        self.bn      = nn.BatchNorm1d(out_channels)
        self.out_dim = out_channels

    def forward(self, x: Tensor) -> Tensor:
        """
        Parameters
        ----------
        x : Tensor  (batch, channels, T_time) — temporal sequence.

        Returns
        -------
        Tensor  (batch, out_channels, T_time)
        """
        # Gated convolution: split into two halves (value + gate)
        out = self.conv(x)                                    # (B, 2*C, T)
        value, gate = out.chunk(2, dim=1)                     # each (B, C, T)
        out = value * torch.sigmoid(gate)                     # gating
        return self.bn(out)


class STGCNLayer(nn.Module):
    """
    One STGCN block: GCN in space + gated conv in time.

    Parameters
    ----------
    in_features  : int  Input node feature dim.
    out_features : int  Output node feature dim.
    temporal_k   : int  Temporal convolution kernel size.
    dropout      : float Dropout rate.
    """

    def __init__(
        self,
        in_features  : int,
        out_features : int,
        temporal_k   : int   = 3,
        dropout      : float = 0.4,
    ):
        super().__init__()
        self.gcn     = GraphConvLayer(in_features, out_features)
        self.tcn     = TemporalConvBlock(out_features, out_features, temporal_k)
        self.dropout = nn.Dropout(p=dropout)
        self.relu    = nn.ReLU()

        # Residual projection if dimensions differ
        self.residual = (
            nn.Linear(in_features, out_features)
            if in_features != out_features else nn.Identity()
        )
        self.layer_norm = nn.LayerNorm(out_features)

    def forward(
        self,
        x        : Tensor,
        adj_norm : Tensor,
    ) -> Tensor:
        """
        Parameters
        ----------
        x        : Tensor  (batch, T, N, F_in)
        adj_norm : Tensor  (N, N) or (batch, N, N)

        Returns
        -------
        Tensor  (batch, T, N, F_out)
        """
        B, T, N, F = x.shape

        # ── Spatial: apply GCN at each time step ──────────────────────────
        x_spatial = x.reshape(B * T, N, F)
        if adj_norm.dim() == 2:
            adj_exp = adj_norm.unsqueeze(0).expand(B * T, -1, -1)
        else:
            adj_exp = adj_norm.unsqueeze(1).expand(-1, T, -1, -1).reshape(B*T, N, N)

        h = self.relu(self.gcn(x_spatial, adj_exp))           # (B*T, N, F_out)
        h = h.reshape(B, T, N, -1)                            # (B, T, N, F_out)

        # ── Temporal: aggregate across nodes then apply TCN ───────────────
        h_mean = h.mean(dim=2)                                 # (B, T, F_out)
        h_t    = h_mean.permute(0, 2, 1)                       # (B, F_out, T)
        h_t    = self.tcn(h_t)                                 # (B, F_out, T)
        h_t    = h_t.permute(0, 2, 1).unsqueeze(2)             # (B, T, 1, F_out)
        h      = h + h_t.expand_as(h)                         # broadcast back

        # ── Residual + norm ───────────────────────────────────────────────
        res  = self.residual(x)
        h    = self.layer_norm(h + res)
        return self.dropout(h)


class STGCNEncoder(nn.Module):
    """
    Full STGCN encoder producing a fixed-length graph embedding.

    Parameters
    ----------
    node_features : int   Input node feature dim (band powers, default 5).
    n_nodes       : int   Number of EEG electrodes (default 23).
    hidden_dims   : list  GCN layer sizes (default [64, 32]).
    out_dim       : int   Final embedding dim (default 32).
    temporal_k    : int   Temporal conv kernel (default 3).
    dropout       : float Dropout rate (default 0.4).
    """

    def __init__(
        self,
        node_features : int   = 5,
        n_nodes       : int   = 23,
        hidden_dims   : List  = None,
        out_dim       : int   = 32,
        temporal_k    : int   = 3,
        dropout       : float = 0.4,
    ):
        super().__init__()

        if hidden_dims is None:
            hidden_dims = [64, 32]

        self.n_nodes    = n_nodes
        self.out_dim    = out_dim

        # Build STGCN layers
        dims = [node_features] + hidden_dims
        self.stgcn_layers = nn.ModuleList([
            STGCNLayer(dims[i], dims[i+1], temporal_k, dropout)
            for i in range(len(hidden_dims))
        ])

        # Final projection
        self.global_pool = "mean"
        self.output_proj = nn.Linear(hidden_dims[-1], out_dim)
        self.layer_norm  = nn.LayerNorm(out_dim)

        self._count_parameters()

    def forward(
        self,
        node_features : Tensor,
        adj_matrices  : Tensor,
    ) -> Tensor:
        """
        Parameters
        ----------
        node_features : Tensor  (batch, T, N, F) — EEG band powers over T steps.
        adj_matrices  : Tensor  (batch, T, N, N) or (N, N) — normalised adjacency.

        Returns
        -------
        embedding : Tensor  (batch, out_dim)
        """
        # Use a single adjacency (time-averaged) for efficiency
        if adj_matrices.dim() == 4:
            adj = adj_matrices.mean(dim=1)   # (B, N, N)
        else:
            adj = adj_matrices               # (N, N) or (B, N, N)

        x = node_features

        # STGCN layers
        for layer in self.stgcn_layers:
            x = layer(x, adj)                # (B, T, N, F')

        # Global mean pooling over time and nodes
        x = x.mean(dim=[1, 2])              # (B, F')

        # Output projection
        embedding = self.layer_norm(self.output_proj(x))  # (B, out_dim)

        return embedding

    def _count_parameters(self):
        total = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"STGCNEncoder: {total:,} trainable parameters")
