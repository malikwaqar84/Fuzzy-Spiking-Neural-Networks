"""
it2_fuzzy.py
────────────
Interval Type-2 Fuzzy Logic System (IT2FLS) Classifier.

Implements:
  - Gaussian IT2 Membership Functions with Footprint of Uncertainty
  - TSK zero-order rule base (15 rules, fuzzy c-means initialisation)
  - Enhanced Karnik-Mendel (EKM) type reduction algorithm
  - Defuzzification to crisp pre-ictal probability

References:
  Mendel, "Uncertain Rule-Based Fuzzy Logic Systems", Springer, 2017.
  Wu & Mendel, "Enhanced Karnik-Mendel algorithms",
    IEEE Trans. Fuzzy Syst., 2009.
  Liang & Mendel, "IT2 fuzzy logic systems: Theory and design",
    IEEE Trans. Fuzzy Syst., 2000.
"""

import logging
import numpy as np
import torch
import torch.nn as nn
from torch import Tensor
from typing import Tuple

logger = logging.getLogger(__name__)


class GaussianIT2MF(nn.Module):
    """
    Gaussian Interval Type-2 Membership Function.

    Upper MF: μ_U(x) = exp(-0.5 * ((x - c) / σ_U)^2)
    Lower MF: μ_L(x) = exp(-0.5 * ((x - c) / σ_L)^2)

    The Footprint of Uncertainty (FOU) is the region between μ_L and μ_U.

    Parameters
    ----------
    n_features   : int   Input dimensionality.
    n_rules      : int   Number of fuzzy rules.
    sigma_lower  : float Lower sigma (tighter bound, default 0.8).
    sigma_upper  : float Upper sigma (wider bound, default 1.2).
    """

    def __init__(
        self,
        n_features  : int,
        n_rules     : int,
        sigma_lower : float = 0.8,
        sigma_upper : float = 1.2,
    ):
        super().__init__()
        self.n_features  = n_features
        self.n_rules     = n_rules

        # Learnable rule centres
        self.centres = nn.Parameter(
            torch.randn(n_rules, n_features) * 0.1
        )

        # Learnable standard deviations (lower and upper)
        self.sigma_L = nn.Parameter(
            torch.ones(n_rules, n_features) * sigma_lower
        )
        self.sigma_U = nn.Parameter(
            torch.ones(n_rules, n_features) * sigma_upper
        )

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor]:
        """
        Compute upper and lower membership degrees.

        Parameters
        ----------
        x : Tensor  (batch, n_features)

        Returns
        -------
        mu_lower : Tensor  (batch, n_rules) — lower MF values
        mu_upper : Tensor  (batch, n_rules) — upper MF values
        """
        # x: (B, F) → (B, 1, F) ; centres: (R, F) → (1, R, F)
        x_exp  = x.unsqueeze(1)                                # (B, 1, F)
        c_exp  = self.centres.unsqueeze(0)                     # (1, R, F)
        sL_exp = torch.abs(self.sigma_L).unsqueeze(0) + 1e-8   # (1, R, F)
        sU_exp = torch.abs(self.sigma_U).unsqueeze(0) + 1e-8   # (1, R, F)

        diff = x_exp - c_exp                                   # (B, R, F)

        mu_upper = torch.exp(-0.5 * (diff / sU_exp) ** 2)     # (B, R, F)
        mu_lower = torch.exp(-0.5 * (diff / sL_exp) ** 2)     # (B, R, F)

        # Product T-norm across features
        mu_U = mu_upper.prod(dim=-1)                           # (B, R)
        mu_L = mu_lower.prod(dim=-1)                           # (B, R)

        # Ensure μ_L ≤ μ_U
        mu_L = torch.min(mu_L, mu_U)

        return mu_L, mu_U


class IT2FuzzyClassifier(nn.Module):
    """
    Full IT2 Fuzzy Logic System for seizure state classification.

    Input  : f ∈ R^96  (concatenated SNN + Graph embeddings)
    Output : ŷ ∈ [0,1]  (pre-ictal probability)

    Parameters
    ----------
    input_dim    : int   Combined feature dimension (default 96).
    n_classes    : int   Number of output classes (default 3).
    n_rules      : int   Number of TSK rules (default 15).
    sigma_lower  : float FOU lower sigma (default 0.8).
    sigma_upper  : float FOU upper sigma (default 1.2).
    """

    def __init__(
        self,
        input_dim    : int   = 96,
        n_classes    : int   = 3,
        n_rules      : int   = 15,
        sigma_lower  : float = 0.8,
        sigma_upper  : float = 1.2,
    ):
        super().__init__()

        self.input_dim  = input_dim
        self.n_classes  = n_classes
        self.n_rules    = n_rules

        # IT2 Membership Functions (one set per class)
        self.mf_layers = nn.ModuleList([
            GaussianIT2MF(input_dim, n_rules, sigma_lower, sigma_upper)
            for _ in range(n_classes)
        ])

        # TSK zero-order consequents: one scalar per rule per class
        self.consequents = nn.Parameter(
            torch.randn(n_classes, n_rules) * 0.1
        )

        # Input normalisation
        self.input_norm = nn.LayerNorm(input_dim)

        self._init_weights()

    def _init_weights(self):
        for mf in self.mf_layers:
            nn.init.xavier_normal_(mf.centres)

    def forward(self, x: Tensor) -> Tensor:
        """
        Full IT2FLS forward pass.

        Parameters
        ----------
        x : Tensor  (batch, input_dim)

        Returns
        -------
        probs : Tensor  (batch, n_classes) — class probabilities via softmax.
        """
        x = self.input_norm(x)

        class_outputs = []
        for cls_idx in range(self.n_classes):
            # 1. Compute firing strengths (lower and upper)
            f_lower, f_upper = self.mf_layers[cls_idx](x)   # (B, R) each

            # 2. EKM type reduction → type-reduced interval [y_l, y_r]
            y_l, y_r = self._ekm_type_reduction(
                f_lower, f_upper,
                self.consequents[cls_idx]
            )

            # 3. Defuzzification: centroid of interval
            y_crisp = (y_l + y_r) / 2.0                      # (B,)
            class_outputs.append(y_crisp)

        # Stack and normalise to probabilities
        logits = torch.stack(class_outputs, dim=1)            # (B, n_classes)
        return torch.softmax(logits, dim=-1)

    def predict_preictal_prob(self, x: Tensor) -> Tensor:
        """
        Returns the pre-ictal probability (class index 1).

        Parameters
        ----------
        x : Tensor  (batch, input_dim)

        Returns
        -------
        prob : Tensor  (batch,)
        """
        probs = self.forward(x)
        return probs[:, 1]   # pre-ictal class

    # ── EKM Algorithm ────────────────────────────────────────────────────────

    def _ekm_type_reduction(
        self,
        f_lower    : Tensor,
        f_upper    : Tensor,
        consequents: Tensor,
    ) -> Tuple[Tensor, Tensor]:
        """
        Enhanced Karnik-Mendel (EKM) algorithm for type reduction.
        Computes the type-reduced interval [y_l, y_r].

        Parameters
        ----------
        f_lower     : Tensor  (batch, n_rules) — lower firing strengths.
        f_upper     : Tensor  (batch, n_rules) — upper firing strengths.
        consequents : Tensor  (n_rules,) — rule output scalars.

        Returns
        -------
        y_l : Tensor  (batch,) — left endpoint of type-reduced set.
        y_r : Tensor  (batch,) — right endpoint of type-reduced set.
        """
        B, R = f_lower.shape
        c    = consequents                                     # (R,)
        c_exp = c.unsqueeze(0).expand(B, -1)                  # (B, R)

        # Sort by consequents (ascending for left, descending for right)
        sort_idx = torch.argsort(c_exp, dim=1)

        c_sorted_asc   = c_exp.gather(1, sort_idx)
        fU_sorted_asc  = f_upper.gather(1, sort_idx)
        fL_sorted_asc  = f_lower.gather(1, sort_idx)

        # ── Left endpoint y_l (use lower MF for k≤L, upper for k>L) ───────
        y_l = self._ekm_iterate(
            c_sorted_asc, fL_sorted_asc, fU_sorted_asc, direction="left"
        )

        # ── Right endpoint y_r (reverse sort, swap lower/upper role) ───────
        sort_idx_desc  = sort_idx.flip(dims=[1])
        c_sorted_desc  = c_exp.gather(1, sort_idx_desc)
        fU_sorted_desc = f_upper.gather(1, sort_idx_desc)
        fL_sorted_desc = f_lower.gather(1, sort_idx_desc)

        y_r = self._ekm_iterate(
            c_sorted_desc, fU_sorted_desc, fL_sorted_desc, direction="right"
        )

        return y_l, y_r

    def _ekm_iterate(
        self,
        c    : Tensor,
        f_a  : Tensor,
        f_b  : Tensor,
        direction : str = "left",
        max_iter  : int = 100,
        tol       : float = 1e-6,
    ) -> Tensor:
        """
        EKM iterative procedure for one endpoint.
        """
        B, R = c.shape

        # Initialise switch point L
        L = torch.full((B,), R // 2, dtype=torch.long, device=c.device)

        for _ in range(max_iter):
            # Build firing strength vector: f_a[:L], f_b[L:]
            L_exp     = L.unsqueeze(1).expand(-1, R)           # (B, R)
            idx       = torch.arange(R, device=c.device).unsqueeze(0).expand(B, -1)
            use_a     = (idx < L_exp).float()
            f_current = use_a * f_a + (1.0 - use_a) * f_b     # (B, R)

            # Weighted centroid
            num   = (f_current * c).sum(dim=1)                 # (B,)
            denom = f_current.sum(dim=1) + 1e-8                # (B,)
            y     = num / denom                                 # (B,)

            # Find new switch point: last k where c[k] ≤ y
            y_exp     = y.unsqueeze(1).expand(-1, R)           # (B, R)
            cond      = (c <= y_exp).float()
            L_new     = cond.sum(dim=1).long().clamp(0, R - 1) # (B,)

            if (L_new == L).all():
                break
            L = L_new

        return y
