"""
causal_graph.py
───────────────
Granger Causality-Based Dynamic Brain Graph Construction.

Steps:
  1. ADF stationarity test + first-order differencing if needed
  2. MVAR model fitting (AIC/BIC order selection)
  3. Pairwise Granger F-test (Eq. 3 from paper)
  4. Directed adjacency matrix A ∈ R^{N×N}
  5. Node feature matrix X ∈ R^{N×5} (EEG band powers)

Reference:
  Granger, C.W.J., Econometrica, 1969.
  Barnett & Seth, Physical Review E, 2015.
"""

import logging
import warnings
from typing import Optional, Tuple

import numpy as np
from scipy import stats
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.api import VAR

from src.preprocessing.filters import extract_band_powers

logger = logging.getLogger(__name__)

# EEG frequency bands for node features
EEG_BANDS = {
    "delta": (0.5,  4.0),
    "theta": (4.0,  8.0),
    "alpha": (8.0,  13.0),
    "beta" : (13.0, 30.0),
    "gamma": (30.0, 40.0),
}


class GrangerCausalityGraph:
    """
    Constructs a directed weighted brain graph from multi-channel EEG
    using Granger causality.

    Parameters
    ----------
    sfreq        : float  Sampling frequency (Hz, default 256).
    max_order    : int    Maximum MVAR lag order (default 20).
    min_order    : int    Minimum MVAR lag order (default 5).
    criterion    : str    Order selection: 'aic' | 'bic' (default 'aic').
    alpha        : float  Granger F-test significance level (default 0.05).
    adf_alpha    : float  ADF stationarity significance (default 0.01).
    """

    def __init__(
        self,
        sfreq     : float = 256.0,
        max_order : int   = 20,
        min_order : int   = 5,
        criterion : str   = "aic",
        alpha     : float = 0.05,
        adf_alpha : float = 0.01,
    ):
        self.sfreq      = sfreq
        self.max_order  = max_order
        self.min_order  = min_order
        self.criterion  = criterion
        self.alpha      = alpha
        self.adf_alpha  = adf_alpha

    # ── Public API ──────────────────────────────────────────────────────────

    def build_graph(
        self,
        epoch  : np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Build a directed brain graph from a multi-channel EEG epoch.

        Parameters
        ----------
        epoch : np.ndarray  Shape (n_channels, n_samples).
                            60-second window recommended for MVAR reliability.

        Returns
        -------
        adj_matrix    : np.ndarray  Shape (N, N) — directed weighted adjacency.
                        adj[i, j] = F-statistic for i → j causality.
        node_features : np.ndarray  Shape (N, 5) — band power per electrode.
        """
        n_channels = epoch.shape[0]

        # 1. Ensure stationarity
        epoch = self._ensure_stationarity(epoch)

        # 2. Fit MVAR model and get optimal order
        order, var_model, var_result = self._fit_mvar(epoch)

        # 3. Compute pairwise Granger causality
        adj_matrix = self._compute_granger_matrix(
            epoch, order, n_channels
        )

        # 4. Compute node features (band powers)
        node_features = extract_band_powers(epoch, self.sfreq, EEG_BANDS)

        return adj_matrix, node_features

    def build_dynamic_graphs(
        self,
        data       : np.ndarray,
        mvar_window_sec : float = 60.0,
        step_sec        : float = 5.0,
    ) -> Tuple[list, list]:
        """
        Build a sequence of brain graphs using a sliding window.

        Parameters
        ----------
        data            : np.ndarray  Shape (n_channels, n_samples).
        mvar_window_sec : float       Length of MVAR fitting window (s).
        step_sec        : float       Step between consecutive graphs (s).

        Returns
        -------
        adj_matrices    : list of np.ndarray  Each (N, N).
        node_features   : list of np.ndarray  Each (N, 5).
        """
        mvar_samples = int(mvar_window_sec * self.sfreq)
        step_samples = int(step_sec        * self.sfreq)
        n_samples    = data.shape[1]

        adj_list  = []
        feat_list = []

        for start in range(0, n_samples - mvar_samples + 1, step_samples):
            epoch = data[:, start : start + mvar_samples]
            try:
                adj, feats = self.build_graph(epoch)
                adj_list.append(adj)
                feat_list.append(feats)
            except Exception as e:
                logger.warning(f"Graph build failed at t={start}: {e}")
                # Append zero graph as placeholder
                adj_list.append(np.zeros((data.shape[0], data.shape[0])))
                feat_list.append(np.zeros((data.shape[0], len(EEG_BANDS))))

        return adj_list, feat_list

    def adjacency_to_edge_index(
        self,
        adj : np.ndarray,
        threshold: float = 0.0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Convert adjacency matrix to PyG-format edge_index and edge_weight.

        Parameters
        ----------
        adj       : np.ndarray  Shape (N, N).
        threshold : float       Minimum weight to include an edge.

        Returns
        -------
        edge_index  : np.ndarray  Shape (2, E) — source, target pairs.
        edge_weight : np.ndarray  Shape (E,)   — Granger F-statistics.
        """
        rows, cols = np.where(adj > threshold)
        edge_index  = np.stack([rows, cols], axis=0)
        edge_weight = adj[rows, cols]
        return edge_index, edge_weight

    # ── Private methods ─────────────────────────────────────────────────────

    def _ensure_stationarity(self, data: np.ndarray) -> np.ndarray:
        """
        Test each channel for stationarity (ADF test).
        First-order difference non-stationary channels.
        """
        result = data.copy()
        for ch in range(data.shape[0]):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                try:
                    adf_pvalue = adfuller(data[ch], autolag="AIC")[1]
                    if adf_pvalue > self.adf_alpha:
                        # Non-stationary: first-order difference
                        result[ch, 1:] = np.diff(data[ch])
                        result[ch, 0]  = 0.0
                except Exception:
                    pass
        return result

    def _fit_mvar(
        self,
        data : np.ndarray,
    ) -> Tuple[int, object, object]:
        """
        Fit a Vector Autoregression (VAR) model and select optimal order.

        Returns
        -------
        order      : int    Selected lag order.
        var_model  : VAR    Fitted statsmodels VAR model.
        var_result :        statsmodels VAR fit result.
        """
        # Transpose: statsmodels expects (n_obs, n_vars)
        data_t = data.T

        var_model = VAR(data_t)

        # Select order via information criterion
        order_result = var_model.select_order(
            maxlags=self.max_order,
            trend="n",
        )

        if self.criterion == "aic":
            order = order_result.aic
        else:
            order = order_result.bic

        order = max(self.min_order, min(order, self.max_order))

        var_result = var_model.fit(maxlags=order, trend="n", verbose=False)

        return order, var_model, var_result

    def _compute_granger_matrix(
        self,
        data       : np.ndarray,
        order      : int,
        n_channels : int,
    ) -> np.ndarray:
        """
        Compute pairwise Granger F-statistics.

        For each pair (i → j), the F-statistic quantifies how much
        the history of channel i improves prediction of channel j.

        F(i→j) = ln(RSS_restricted(j) / RSS_unrestricted(j))
        """
        from statsmodels.tsa.stattools import grangercausalitytests

        adj = np.zeros((n_channels, n_channels), dtype=np.float32)
        data_t = data.T  # (n_obs, n_channels)

        for j in range(n_channels):
            for i in range(n_channels):
                if i == j:
                    continue
                try:
                    # grangercausalitytests: test if channel i Granger-causes j
                    test_data = data_t[:, [j, i]]  # [target, predictor]
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        gc_res = grangercausalitytests(
                            test_data, maxlag=order, verbose=False
                        )
                    # Use F-test at optimal lag
                    f_stat  = gc_res[order][0]["ssr_ftest"][0]
                    p_value = gc_res[order][0]["ssr_ftest"][1]

                    if p_value < self.alpha:
                        adj[i, j] = float(f_stat)

                except Exception:
                    pass

        return adj


def normalise_adjacency(adj: np.ndarray) -> np.ndarray:
    """
    Symmetric normalisation for GCN: D^{-1/2} A D^{-1/2}.
    Adds self-loops (Ã = A + I) before normalisation.
    """
    n = adj.shape[0]
    adj_tilde = adj + np.eye(n)                          # Ã = A + I
    degree    = adj_tilde.sum(axis=1)                    # degree vector
    D_invsqrt = np.diag(1.0 / np.sqrt(degree + 1e-8))
    return D_invsqrt @ adj_tilde @ D_invsqrt
