"""
segmentation.py
───────────────
Window extraction and class labelling for seizure prediction.

Labels:
  0 = Interictal  (normal background EEG, >4h from any seizure)
  1 = Pre-ictal   (30 minutes immediately before seizure onset)
  2 = Ictal       (during seizure)
"""

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
from torch.utils.data import Dataset

from src.preprocessing.loader import SeizureAnnotation

logger = logging.getLogger(__name__)

# Class labels
INTERICTAL = 0
PREICTAL   = 1
ICTAL      = 2

LABEL_NAMES = {0: "Interictal", 1: "Pre-ictal", 2: "Ictal"}


class EEGWindowDataset(Dataset):
    """
    PyTorch Dataset of fixed-length EEG windows with class labels.

    Parameters
    ----------
    windows : np.ndarray   Shape (N, n_channels, window_samples).
    labels  : np.ndarray   Shape (N,), values in {0, 1, 2}.
    subject_ids : list     Subject ID for each window (for stratification).
    """

    def __init__(
        self,
        windows    : np.ndarray,
        labels     : np.ndarray,
        subject_ids: Optional[List[int]] = None,
    ):
        assert len(windows) == len(labels), "windows and labels must match"
        self.windows     = windows.astype(np.float32)
        self.labels      = labels.astype(np.int64)
        self.subject_ids = subject_ids or [0] * len(windows)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        import torch
        return (
            torch.from_numpy(self.windows[idx]),
            torch.tensor(self.labels[idx]),
        )

    @property
    def class_counts(self) -> Dict[int, int]:
        unique, counts = np.unique(self.labels, return_counts=True)
        return dict(zip(unique.tolist(), counts.tolist()))

    def __repr__(self):
        cc = self.class_counts
        return (
            f"EEGWindowDataset(N={len(self)}, "
            f"interictal={cc.get(0,0)}, preictal={cc.get(1,0)}, "
            f"ictal={cc.get(2,0)})"
        )


class WindowExtractor:
    """
    Extracts non-overlapping EEG windows and assigns class labels
    based on seizure annotation timestamps.

    Parameters
    ----------
    window_sec       : float  Window length in seconds (default 5.0).
    overlap          : float  Fraction of overlap [0, 1) (default 0.0).
    preictal_min     : float  Pre-ictal horizon in minutes (default 30).
    interictal_gap_h : float  Minimum distance from seizure for interictal (h).
    sfreq            : float  Sampling frequency (Hz, default 256).
    """

    def __init__(
        self,
        window_sec       : float = 5.0,
        overlap          : float = 0.0,
        preictal_min     : float = 30.0,
        interictal_gap_h : float = 4.0,
        sfreq            : float = 256.0,
    ):
        self.window_sec        = window_sec
        self.overlap           = overlap
        self.preictal_sec      = preictal_min * 60.0
        self.interictal_gap    = interictal_gap_h * 3600.0
        self.sfreq             = sfreq
        self.window_samples    = int(window_sec * sfreq)
        self.step_samples      = int(self.window_samples * (1 - overlap))

    def extract(
        self,
        data        : np.ndarray,
        annotations : List[SeizureAnnotation],
        file_start_sec: float = 0.0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract windows from a single EEG recording and assign labels.

        Parameters
        ----------
        data           : np.ndarray  Shape (n_channels, n_samples).
        annotations    : list        SeizureAnnotation list for this file.
        file_start_sec : float       Absolute start time of this file (seconds).

        Returns
        -------
        windows : np.ndarray  Shape (N, n_channels, window_samples).
        labels  : np.ndarray  Shape (N,).
        """
        n_channels, n_samples = data.shape
        n_windows = (n_samples - self.window_samples) // self.step_samples + 1

        windows_list = []
        labels_list  = []

        for w_idx in range(n_windows):
            start_sample = w_idx * self.step_samples
            end_sample   = start_sample + self.window_samples

            if end_sample > n_samples:
                break

            # Absolute time of window centre
            centre_sec = file_start_sec + (
                (start_sample + self.window_samples / 2) / self.sfreq
            )

            label = self._assign_label(centre_sec, annotations)
            if label is None:
                continue  # skip ambiguous windows

            window = data[:, start_sample:end_sample]
            windows_list.append(window)
            labels_list.append(label)

        if not windows_list:
            return np.empty((0, n_channels, self.window_samples)), np.empty(0)

        return np.stack(windows_list), np.array(labels_list, dtype=np.int64)

    def extract_mvar_epochs(
        self,
        data        : np.ndarray,
        annotations : List[SeizureAnnotation],
        file_start_sec: float = 0.0,
        mvar_window_sec: float = 60.0,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract longer 60-second epochs for Granger MVAR model fitting.
        These overlap with the 5-second windows and share labels.
        """
        mvar_samples = int(mvar_window_sec * self.sfreq)
        n_channels, n_samples = data.shape
        epochs_list = []
        labels_list = []

        for start in range(0, n_samples - mvar_samples, mvar_samples):
            centre_sec = file_start_sec + (
                (start + mvar_samples / 2) / self.sfreq
            )
            label = self._assign_label(centre_sec, annotations)
            if label is None:
                continue
            epochs_list.append(data[:, start:start + mvar_samples])
            labels_list.append(label)

        if not epochs_list:
            return np.empty((0, n_channels, mvar_samples)), np.empty(0)

        return np.stack(epochs_list), np.array(labels_list, dtype=np.int64)

    # ── Private ─────────────────────────────────────────────────────────────

    def _assign_label(
        self,
        time_sec    : float,
        annotations : List[SeizureAnnotation],
    ) -> Optional[int]:
        """
        Assign a label to a window at absolute time time_sec.

        Rules (in priority order):
          ICTAL      : within seizure onset..offset
          PREICTAL   : within [onset - preictal_sec, onset)
          INTERICTAL : farther than interictal_gap from all seizures
          None       : ambiguous (peri-ictal but not labelled)
        """
        for ann in annotations:
            # Ictal
            if ann.onset_sec <= time_sec <= ann.offset_sec:
                return ICTAL

            # Pre-ictal
            preictal_start = ann.onset_sec - self.preictal_sec
            if preictal_start <= time_sec < ann.onset_sec:
                return PREICTAL

        # Check interictal gap
        for ann in annotations:
            dist = min(
                abs(time_sec - ann.onset_sec),
                abs(time_sec - ann.offset_sec),
            )
            if dist < self.interictal_gap:
                return None  # ambiguous peri-ictal zone

        return INTERICTAL
