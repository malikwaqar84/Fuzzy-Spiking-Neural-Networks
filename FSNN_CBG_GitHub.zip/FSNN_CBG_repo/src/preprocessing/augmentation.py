"""
augmentation.py
───────────────
SMOTE-based class balancing for pre-ictal / interictal imbalance.
Operates in flattened feature space; also provides time-domain
augmentation utilities (Gaussian noise, time-shift).
"""

import logging
import numpy as np
from typing import Tuple

logger = logging.getLogger(__name__)


def smote_balance(
    windows : np.ndarray,
    labels  : np.ndarray,
    target_ratio: float = 0.25,
    k_neighbors : int   = 5,
    random_state: int   = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Apply SMOTE to balance pre-ictal (minority) and interictal (majority) classes.

    Parameters
    ----------
    windows      : np.ndarray  Shape (N, n_channels, window_samples).
    labels       : np.ndarray  Shape (N,).
    target_ratio : float       Desired pre-ictal:interictal ratio (default 0.25 → 1:4).
    k_neighbors  : int         SMOTE k-nearest neighbours (default 5).
    random_state : int         Random seed.

    Returns
    -------
    windows_bal : np.ndarray   Balanced windows.
    labels_bal  : np.ndarray   Balanced labels.
    """
    try:
        from imblearn.over_sampling import SMOTE
    except ImportError:
        logger.warning(
            "imbalanced-learn not installed. "
            "Falling back to random oversampling."
        )
        return _random_oversample(windows, labels, target_ratio, random_state)

    n, c, t = windows.shape
    X_flat  = windows.reshape(n, -1)   # (N, C*T)
    y       = labels

    # Only balance pre-ictal vs interictal (exclude ictal)
    preictal_mask    = y == 1
    interictal_mask  = y == 0
    ictal_mask       = y == 2

    n_interictal = interictal_mask.sum()
    n_preictal   = preictal_mask.sum()

    desired_preictal = int(n_interictal * target_ratio)

    if n_preictal >= desired_preictal:
        logger.info("No SMOTE needed: pre-ictal count already sufficient")
        return windows, labels

    sampling_strategy = {1: desired_preictal}

    smote = SMOTE(
        sampling_strategy=sampling_strategy,
        k_neighbors=min(k_neighbors, n_preictal - 1),
        random_state=random_state,
    )

    # Only SMOTE on pre-ictal + interictal
    mask_binary   = preictal_mask | interictal_mask
    X_bin         = X_flat[mask_binary]
    y_bin         = y[mask_binary]

    X_resampled, y_resampled = smote.fit_resample(X_bin, y_bin)

    # Reconstruct and add ictal back
    X_resampled = X_resampled.reshape(-1, c, t)

    if ictal_mask.any():
        X_resampled = np.concatenate([X_resampled, windows[ictal_mask]], axis=0)
        y_resampled = np.concatenate([y_resampled, y[ictal_mask]], axis=0)

    # Shuffle
    rng  = np.random.default_rng(random_state)
    perm = rng.permutation(len(y_resampled))

    logger.info(
        f"SMOTE: {n_preictal} → {(y_resampled==1).sum()} pre-ictal samples "
        f"(ratio 1:{int(1/target_ratio)})"
    )

    return X_resampled[perm], y_resampled[perm]


def _random_oversample(
    windows : np.ndarray,
    labels  : np.ndarray,
    target_ratio: float,
    random_state: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Fallback: simple random oversampling of minority class."""
    rng = np.random.default_rng(random_state)
    preictal_idx    = np.where(labels == 1)[0]
    interictal_idx  = np.where(labels == 0)[0]

    desired = int(len(interictal_idx) * target_ratio)
    n_to_add = max(0, desired - len(preictal_idx))

    if n_to_add == 0:
        return windows, labels

    extra_idx = rng.choice(preictal_idx, size=n_to_add, replace=True)
    windows_bal = np.concatenate([windows, windows[extra_idx]], axis=0)
    labels_bal  = np.concatenate([labels,  labels[extra_idx]],  axis=0)
    perm        = rng.permutation(len(labels_bal))
    return windows_bal[perm], labels_bal[perm]


def add_gaussian_noise(
    windows    : np.ndarray,
    snr_db     : float = 20.0,
    random_state: int  = 42,
) -> np.ndarray:
    """
    Add Gaussian noise to EEG windows at a given SNR.

    Parameters
    ----------
    windows    : np.ndarray  Shape (N, C, T).
    snr_db     : float       Signal-to-noise ratio in dB (default 20).
    random_state : int

    Returns
    -------
    noisy_windows : np.ndarray  Same shape as input.
    """
    rng         = np.random.default_rng(random_state)
    signal_power = (windows ** 2).mean()
    noise_power  = signal_power / (10 ** (snr_db / 10))
    noise        = rng.normal(0, np.sqrt(noise_power), size=windows.shape)
    return (windows + noise).astype(windows.dtype)


def time_shift_augment(
    windows    : np.ndarray,
    labels     : np.ndarray,
    max_shift  : int = 64,
    random_state: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Augment by randomly time-shifting each window.

    Parameters
    ----------
    windows   : np.ndarray  Shape (N, C, T).
    labels    : np.ndarray  Shape (N,).
    max_shift : int         Maximum shift in samples (default 64 = 250ms @ 256Hz).

    Returns
    -------
    Augmented (windows, labels) concatenated with originals.
    """
    rng         = np.random.default_rng(random_state)
    N, C, T     = windows.shape
    shifts      = rng.integers(-max_shift, max_shift, size=N)
    augmented   = np.array([
        np.roll(windows[i], shifts[i], axis=-1) for i in range(N)
    ])
    return (
        np.concatenate([windows, augmented], axis=0),
        np.concatenate([labels,  labels],    axis=0),
    )
