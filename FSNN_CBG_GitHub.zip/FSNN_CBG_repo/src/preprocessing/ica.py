"""
ica.py
──────
ICA-based EEG artefact removal.
Identifies and removes EOG (eye), EMG (muscle), and ECG (cardiac)
artefact components using FastICA with heuristic component detection.
"""

import logging
import numpy as np
import mne
from mne.preprocessing import ICA

logger = logging.getLogger(__name__)


class ICAArtefactRemover:
    """
    Applies FastICA to remove physiological artefacts from EEG.

    Parameters
    ----------
    n_components    : int    Number of ICA components (default: n_channels).
    method          : str    ICA algorithm: 'fastica' | 'picard' | 'infomax'.
    eog_threshold   : float  Correlation threshold for EOG detection (default 0.80).
    random_state    : int    Random seed for reproducibility.
    """

    def __init__(
        self,
        n_components  : int   = 23,
        method        : str   = "fastica",
        eog_threshold : float = 0.80,
        random_state  : int   = 42,
    ):
        self.n_components  = n_components
        self.method        = method
        self.eog_threshold = eog_threshold
        self.random_state  = random_state

    def fit_transform(self, raw: mne.io.Raw) -> mne.io.Raw:
        """
        Fit ICA on raw data and remove detected artefact components.

        Parameters
        ----------
        raw : mne.io.Raw   Preprocessed (filtered) EEG.

        Returns
        -------
        raw : mne.io.Raw   Artefact-cleaned EEG.
        """
        n_comp = min(self.n_components, len(raw.ch_names))

        ica = ICA(
            n_components=n_comp,
            method=self.method,
            random_state=self.random_state,
            max_iter="auto",
        )

        ica.fit(raw, verbose=False)

        # Identify artefact components
        excluded = []
        excluded += self._detect_eog_components(ica, raw)
        excluded += self._detect_ecg_components(ica, raw)

        excluded = list(set(excluded))  # deduplicate

        if excluded:
            ica.exclude = excluded
            ica.apply(raw, verbose=False)
            logger.info(
                f"ICA: removed {len(excluded)} artefact components "
                f"(indices: {excluded})"
            )
        else:
            logger.info("ICA: no artefact components detected")

        return raw

    # ── Component detection ─────────────────────────────────────────────────

    def _detect_eog_components(
        self,
        ica: ICA,
        raw: mne.io.Raw,
    ) -> list:
        """
        Detect EOG components by correlation with frontal channels (Fp1, Fp2).
        Falls back to heuristic kurtosis-based detection if frontal channels
        are absent.
        """
        frontal_candidates = ["FP1-F7", "FP1-F3", "FP2-F4", "FP2-F8", "Fp1", "Fp2"]
        frontal_ch = [ch for ch in frontal_candidates if ch in raw.ch_names]

        if frontal_ch:
            try:
                eog_indices, eog_scores = ica.find_bads_eog(
                    raw,
                    ch_name=frontal_ch[0],
                    threshold=self.eog_threshold,
                    verbose=False,
                )
                return list(eog_indices)
            except Exception as e:
                logger.warning(f"EOG detection failed: {e}. Using kurtosis fallback.")

        # Kurtosis-based fallback: high kurtosis → artefact
        return self._kurtosis_detection(ica, raw, top_k=2)

    def _detect_ecg_components(
        self,
        ica: ICA,
        raw: mne.io.Raw,
    ) -> list:
        """
        Detect cardiac artefact components by spectral analysis.
        Components with strong ~1 Hz (60 bpm) power are flagged.
        """
        try:
            ecg_indices, _ = ica.find_bads_ecg(
                raw,
                method="correlation",
                verbose=False,
            )
            return list(ecg_indices)
        except Exception:
            return []

    def _kurtosis_detection(
        self,
        ica: ICA,
        raw: mne.io.Raw,
        top_k: int = 2,
    ) -> list:
        """
        Identify components with excess kurtosis (non-Gaussian artefacts).
        Returns indices of the top_k highest kurtosis components.
        """
        sources = ica.get_sources(raw).get_data()  # (n_comp, n_samples)
        kurt    = np.array([
            float(np.mean((s - s.mean()) ** 4) / (s.std() ** 4 + 1e-8))
            for s in sources
        ])
        # Gaussian kurtosis ≈ 3; artefacts typically much higher
        threshold = kurt.mean() + 2.0 * kurt.std()
        flagged   = np.where(kurt > threshold)[0].tolist()
        return flagged[:top_k]
