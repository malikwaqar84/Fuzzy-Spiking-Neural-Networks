"""
loader.py
─────────
CHB-MIT Scalp EEG Dataset Loader
Loads .edf files, parses seizure annotations from .seizures files,
and returns MNE Raw objects with seizure metadata.

Reference:
  Goldberger et al., PhysioNet, Circulation 2000.
  Shoeb, A.H., MIT PhD Thesis, 2009.
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import mne
import numpy as np

mne.set_log_level("WARNING")
logger = logging.getLogger(__name__)

# Standard 23 CHB-MIT channels (International 10-20)
CHB_MIT_CHANNELS = [
    "FP1-F7", "F7-T7",  "T7-P7",  "P7-O1",
    "FP1-F3", "F3-C3",  "C3-P3",  "P3-O1",
    "FP2-F4", "F4-C4",  "C4-P4",  "P4-O2",
    "FP2-F8", "F8-T8",  "T8-P8",  "P8-O2",
    "FZ-CZ",  "CZ-PZ",
    "P7-T7",  "T7-FT9", "FT9-FT10","FT10-T8",
    "T8-P8-0",
]

SAMPLING_RATE = 256   # Hz
N_CHANNELS    = 23


class SeizureAnnotation:
    """Holds a single seizure onset/offset annotation."""

    def __init__(self, onset_sec: float, offset_sec: float,
                 subject: str, file_name: str):
        self.onset_sec  = onset_sec
        self.offset_sec = offset_sec
        self.duration   = offset_sec - onset_sec
        self.subject    = subject
        self.file_name  = file_name

    def __repr__(self):
        return (f"SeizureAnnotation(subject={self.subject}, "
                f"onset={self.onset_sec:.1f}s, "
                f"duration={self.duration:.1f}s)")


class CHBMITLoader:
    """
    Loads the CHB-MIT Scalp EEG Database from a local directory.

    Parameters
    ----------
    root_dir : str
        Path to the root of the CHB-MIT dataset (e.g. 'data/chbmit').
    subjects : list of int or 'all'
        Which subject IDs to load (1-24). 'all' loads everything.
    preictal_min : float
        Duration of the pre-ictal window in minutes (default 30).
    interictal_gap_h : float
        Minimum distance from any seizure to label a segment interictal (default 4h).

    Example
    -------
    >>> loader = CHBMITLoader(root_dir='data/chbmit', subjects='all')
    >>> subject_data = loader.load_subject(1)
    >>> raw, annotations = subject_data['raw'][0], subject_data['annotations']
    """

    def __init__(
        self,
        root_dir: str,
        subjects  = "all",
        preictal_min: float = 30.0,
        interictal_gap_h: float = 4.0,
    ):
        self.root_dir         = Path(root_dir)
        self.preictal_sec     = preictal_min * 60.0
        self.interictal_gap   = interictal_gap_h * 3600.0

        # Resolve subject list
        if subjects == "all":
            self.subjects = list(range(1, 25))
        else:
            self.subjects = list(subjects)

        logger.info(
            f"CHBMITLoader initialised | root={root_dir} | "
            f"subjects={self.subjects} | preictal={preictal_min}min"
        )

    # ── Public API ──────────────────────────────────────────────────────────

    def load_subject(self, subject_id: int) -> Dict:
        """
        Load all EDF files and seizure annotations for one subject.

        Returns
        -------
        dict with keys:
          'subject'     : int
          'raw'         : list of mne.io.Raw
          'annotations' : list of SeizureAnnotation
          'file_paths'  : list of Path
        """
        subject_dir = self._get_subject_dir(subject_id)
        if not subject_dir.exists():
            raise FileNotFoundError(
                f"Subject directory not found: {subject_dir}"
            )

        annotations  = self._parse_summary(subject_id)
        edf_paths    = sorted(subject_dir.glob("*.edf"))
        raw_list     = []
        valid_paths  = []

        for edf_path in edf_paths:
            try:
                raw = self._load_edf(edf_path)
                if raw is not None:
                    raw_list.append(raw)
                    valid_paths.append(edf_path)
            except Exception as e:
                logger.warning(f"Failed to load {edf_path.name}: {e}")

        logger.info(
            f"Subject chb{subject_id:02d}: loaded {len(raw_list)} files, "
            f"{len(annotations)} seizures"
        )

        return {
            "subject"    : subject_id,
            "raw"        : raw_list,
            "annotations": annotations,
            "file_paths" : valid_paths,
        }

    def load_all_subjects(self) -> List[Dict]:
        """Load all configured subjects and return a list of subject dicts."""
        all_data = []
        for sid in self.subjects:
            subject_dir = self._get_subject_dir(sid)
            if not subject_dir.exists():
                logger.warning(f"Subject chb{sid:02d} directory not found, skipping.")
                continue
            try:
                all_data.append(self.load_subject(sid))
            except Exception as e:
                logger.error(f"Error loading subject {sid}: {e}")
        return all_data

    def get_edf_paths(self, subject_id: int) -> List[Path]:
        """Return sorted list of .edf file paths for a subject."""
        return sorted(self._get_subject_dir(subject_id).glob("*.edf"))

    def get_seizure_count(self) -> Dict[int, int]:
        """Return {subject_id: n_seizures} for all subjects."""
        counts = {}
        for sid in self.subjects:
            try:
                anns = self._parse_summary(sid)
                counts[sid] = len(anns)
            except Exception:
                counts[sid] = 0
        return counts

    # ── Private helpers ─────────────────────────────────────────────────────

    def _get_subject_dir(self, subject_id: int) -> Path:
        return self.root_dir / f"chb{subject_id:02d}"

    def _load_edf(self, edf_path: Path) -> Optional[mne.io.Raw]:
        """
        Load a single .edf file, pick the 23 standard channels,
        and return an MNE Raw object.
        """
        raw = mne.io.read_raw_edf(str(edf_path), preload=True, verbose=False)

        # Normalise channel names: strip whitespace & dots
        raw.rename_channels(
            {ch: ch.strip().replace(".", "-") for ch in raw.ch_names}
        )

        # Pick available standard channels
        available = [ch for ch in CHB_MIT_CHANNELS if ch in raw.ch_names]
        if len(available) < 10:
            logger.warning(
                f"{edf_path.name}: only {len(available)} standard channels "
                f"found, skipping."
            )
            return None

        raw.pick_channels(available)

        # Resample to standard rate if needed
        if abs(raw.info["sfreq"] - SAMPLING_RATE) > 1:
            raw.resample(SAMPLING_RATE)

        return raw

    def _parse_summary(self, subject_id: int) -> List[SeizureAnnotation]:
        """
        Parse the chbXX-summary.txt file to extract seizure
        onset/offset annotations per EDF file.
        """
        summary_path = self._get_subject_dir(subject_id) / \
                       f"chb{subject_id:02d}-summary.txt"

        if not summary_path.exists():
            logger.warning(f"Summary file not found: {summary_path}")
            return []

        annotations = []
        current_file = None

        with open(summary_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()

                # Track current EDF file name
                if line.startswith("File Name:"):
                    current_file = line.split(":", 1)[1].strip()

                # Onset
                onset_match = re.search(
                    r"Seizure(?:\s*\d+)?\s*Start\s*Time\s*:\s*(\d+)\s*second",
                    line, re.IGNORECASE
                )
                if onset_match and current_file:
                    onset_sec = float(onset_match.group(1))
                    annotations.append(
                        SeizureAnnotation(
                            onset_sec  = onset_sec,
                            offset_sec = onset_sec,   # placeholder
                            subject    = f"chb{subject_id:02d}",
                            file_name  = current_file,
                        )
                    )

                # Offset — update last annotation
                offset_match = re.search(
                    r"Seizure(?:\s*\d+)?\s*End\s*Time\s*:\s*(\d+)\s*second",
                    line, re.IGNORECASE
                )
                if offset_match and annotations:
                    annotations[-1].offset_sec = float(offset_match.group(1))

        return annotations

    def get_preictal_interictal_times(
        self,
        annotations: List[SeizureAnnotation],
        recording_duration_sec: float,
    ) -> Tuple[List[Tuple], List[Tuple]]:
        """
        Given a list of seizure annotations and total recording duration,
        return lists of (start, end) tuples for pre-ictal and interictal windows.

        Returns
        -------
        preictal_intervals   : list of (start_sec, end_sec)
        interictal_intervals : list of (start_sec, end_sec)
        """
        if not annotations:
            # Entire recording is interictal
            return [], [(0.0, recording_duration_sec)]

        onsets = [a.onset_sec for a in annotations]
        preictal_intervals   = []
        interictal_intervals = []

        for onset in onsets:
            start = max(0.0, onset - self.preictal_sec)
            end   = onset
            if end > start:
                preictal_intervals.append((start, end))

        # Build interictal: exclude all peri-ictal zones
        exclude = set()
        t = 0.0
        dt = 1.0   # 1-second resolution

        while t < recording_duration_sec:
            is_periictal = any(
                abs(t - onset) < self.interictal_gap
                for onset in onsets
            )
            if is_periictal:
                exclude.add(int(t))
            t += dt

        # Convert exclusion set to intervals
        interictal_start = None
        for t_int in range(int(recording_duration_sec)):
            if t_int not in exclude:
                if interictal_start is None:
                    interictal_start = t_int
            else:
                if interictal_start is not None:
                    interictal_intervals.append(
                        (float(interictal_start), float(t_int))
                    )
                    interictal_start = None
        if interictal_start is not None:
            interictal_intervals.append(
                (float(interictal_start), recording_duration_sec)
            )

        return preictal_intervals, interictal_intervals
