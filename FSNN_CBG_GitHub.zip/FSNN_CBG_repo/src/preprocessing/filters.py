"""
filters.py
──────────
EEG signal filtering pipeline:
  1. Notch filter  (50/60 Hz power-line removal)
  2. Bandpass filter (0.5–40 Hz)
  3. Common Average Referencing (CAR)
  4. Z-score normalisation (per-channel, per-session)
"""

import logging
import numpy as np
import mne
from scipy.signal import iirnotch, filtfilt, butter

logger = logging.getLogger(__name__)


class EEGFilterPipeline:
    """
    Sequential EEG filtering pipeline applied to MNE Raw objects.

    Parameters
    ----------
    notch_freq      : float   Power-line frequency to suppress (Hz).
    notch_bw        : float   Notch bandwidth (Hz, default 2.0).
    bp_low          : float   Bandpass lower cutoff (Hz, default 0.5).
    bp_high         : float   Bandpass upper cutoff (Hz, default 40.0).
    bp_order        : int     Butterworth filter order (default 4).
    apply_car       : bool    Apply Common Average Referencing.
    apply_zscore    : bool    Apply per-channel z-score normalisation.
    """

    def __init__(
        self,
        notch_freq   : float = 50.0,
        notch_bw     : float = 2.0,
        bp_low       : float = 0.5,
        bp_high      : float = 40.0,
        bp_order     : int   = 4,
        apply_car    : bool  = True,
        apply_zscore : bool  = True,
    ):
        self.notch_freq  = notch_freq
        self.notch_bw    = notch_bw
        self.bp_low      = bp_low
        self.bp_high     = bp_high
        self.bp_order    = bp_order
        self.apply_car   = apply_car
        self.apply_zscore = apply_zscore

    def process(self, raw: mne.io.Raw) -> mne.io.Raw:
        """
        Apply the full filtering pipeline to an MNE Raw object.

        Parameters
        ----------
        raw : mne.io.Raw   Input raw EEG (modified in-place).

        Returns
        -------
        raw : mne.io.Raw   Filtered raw EEG.
        """
        sfreq = raw.info["sfreq"]
        logger.debug(f"Filtering: sfreq={sfreq} Hz, {len(raw.ch_names)} channels")

        # 1. Notch filter
        raw = self._apply_notch(raw, sfreq)

        # 2. Bandpass filter
        raw = self._apply_bandpass(raw, sfreq)

        # 3. Common Average Referencing
        if self.apply_car:
            raw = self._apply_car(raw)

        # 4. Z-score normalisation
        if self.apply_zscore:
            raw = self._apply_zscore(raw)

        return raw

    def process_array(
        self,
        data: np.ndarray,
        sfreq: float
    ) -> np.ndarray:
        """
        Apply the filtering pipeline to a raw NumPy array.

        Parameters
        ----------
        data  : np.ndarray  Shape (n_channels, n_samples).
        sfreq : float       Sampling frequency in Hz.

        Returns
        -------
        data : np.ndarray   Filtered array, same shape.
        """
        # 1. Notch
        b_n, a_n = iirnotch(
            w0=self.notch_freq / (sfreq / 2),
            Q=self.notch_freq / self.notch_bw
        )
        data = filtfilt(b_n, a_n, data, axis=-1)

        # 2. Bandpass
        nyq = sfreq / 2.0
        b_bp, a_bp = butter(
            self.bp_order,
            [self.bp_low / nyq, self.bp_high / nyq],
            btype="bandpass"
        )
        data = filtfilt(b_bp, a_bp, data, axis=-1)

        # 3. CAR
        if self.apply_car:
            data = data - data.mean(axis=0, keepdims=True)

        # 4. Z-score
        if self.apply_zscore:
            mu  = data.mean(axis=-1, keepdims=True)
            std = data.std(axis=-1, keepdims=True) + 1e-8
            data = (data - mu) / std

        return data

    # ── Private methods ─────────────────────────────────────────────────────

    def _apply_notch(self, raw: mne.io.Raw, sfreq: float) -> mne.io.Raw:
        """Zero-phase IIR notch filter at notch_freq."""
        raw.notch_filter(
            freqs=self.notch_freq,
            method="iir",
            iir_params={"order": 4, "ftype": "butter"},
            verbose=False,
        )
        logger.debug(f"Notch filter applied at {self.notch_freq} Hz")
        return raw

    def _apply_bandpass(self, raw: mne.io.Raw, sfreq: float) -> mne.io.Raw:
        """Zero-phase Butterworth bandpass filter."""
        raw.filter(
            l_freq=self.bp_low,
            h_freq=self.bp_high,
            method="iir",
            iir_params={"order": self.bp_order, "ftype": "butter"},
            verbose=False,
        )
        logger.debug(
            f"Bandpass filter applied: {self.bp_low}–{self.bp_high} Hz "
            f"(order {self.bp_order})"
        )
        return raw

    def _apply_car(self, raw: mne.io.Raw) -> mne.io.Raw:
        """
        Common Average Referencing: subtract instantaneous
        cross-channel mean at every sample.
        """
        data, times = raw[:]
        data -= data.mean(axis=0, keepdims=True)
        raw._data = data
        logger.debug("Common Average Referencing applied")
        return raw

    def _apply_zscore(self, raw: mne.io.Raw) -> mne.io.Raw:
        """Per-channel z-score normalisation over the full session."""
        data, _ = raw[:]
        mu  = data.mean(axis=1, keepdims=True)
        std = data.std(axis=1, keepdims=True) + 1e-8
        raw._data = (data - mu) / std
        logger.debug("Z-score normalisation applied")
        return raw


def extract_band_powers(
    data: np.ndarray,
    sfreq: float,
    bands: dict = None,
) -> np.ndarray:
    """
    Compute EEG band powers per channel using Welch's method.

    Parameters
    ----------
    data   : np.ndarray  Shape (n_channels, n_samples).
    sfreq  : float       Sampling frequency.
    bands  : dict        Band name → (low_hz, high_hz).

    Returns
    -------
    powers : np.ndarray  Shape (n_channels, n_bands).
    """
    from scipy.signal import welch

    if bands is None:
        bands = {
            "delta": (0.5, 4.0),
            "theta": (4.0, 8.0),
            "alpha": (8.0, 13.0),
            "beta" : (13.0, 30.0),
            "gamma": (30.0, 40.0),
        }

    n_channels = data.shape[0]
    n_bands    = len(bands)
    powers     = np.zeros((n_channels, n_bands))

    for ch_idx in range(n_channels):
        freqs, psd = welch(data[ch_idx], fs=sfreq, nperseg=min(256, data.shape[1]))
        for band_idx, (lo, hi) in enumerate(bands.values()):
            mask = (freqs >= lo) & (freqs < hi)
            powers[ch_idx, band_idx] = np.trapz(psd[mask], freqs[mask])

    return powers
