"""
statistical.py
──────────────
Statistical significance testing for seizure prediction comparisons.

  - Wilcoxon signed-rank test (paired, non-parametric)
  - Cohen's d effect size
  - Multi-method pairwise comparison table
"""

import logging
import numpy as np
from typing import Dict, List, Tuple

from scipy import stats

logger = logging.getLogger(__name__)


def wilcoxon_test(
    scores_a : List[float],
    scores_b : List[float],
    alpha    : float = 0.05,
) -> Dict:
    """
    Wilcoxon signed-rank test between two paired score lists.

    Parameters
    ----------
    scores_a : list  Metric values for method A (per subject).
    scores_b : list  Metric values for method B (per subject).
    alpha    : float Significance level (default 0.05).

    Returns
    -------
    dict with: statistic, p_value, significant, effect_size_d
    """
    assert len(scores_a) == len(scores_b), "Score lists must be equal length"

    a = np.array(scores_a)
    b = np.array(scores_b)

    try:
        stat, p_value = stats.wilcoxon(a, b, alternative="greater")
    except ValueError:
        # All differences are zero
        stat, p_value = 0.0, 1.0

    # Cohen's d effect size
    diff       = a - b
    cohens_d   = diff.mean() / (diff.std(ddof=1) + 1e-8)

    return {
        "statistic"  : float(stat),
        "p_value"    : float(p_value),
        "significant": bool(p_value < alpha),
        "effect_size_d": float(cohens_d),
        "mean_diff"  : float(diff.mean()),
        "std_diff"   : float(diff.std()),
    }


def pairwise_comparison(
    method_names  : List[str],
    method_scores : Dict[str, List[float]],
    proposed_name : str,
    alpha         : float = 0.05,
) -> Dict:
    """
    Compare proposed method against all baselines using Wilcoxon test.

    Parameters
    ----------
    method_names  : list  All method names.
    method_scores : dict  method_name → per-subject sensitivity list.
    proposed_name : str   Name of the proposed method.
    alpha         : float Significance level.

    Returns
    -------
    results : dict  method_name → Wilcoxon result dict.
    """
    proposed_scores = method_scores[proposed_name]
    results = {}

    for name in method_names:
        if name == proposed_name:
            continue
        if name not in method_scores:
            logger.warning(f"No scores found for {name}, skipping")
            continue
        results[name] = wilcoxon_test(
            proposed_scores,
            method_scores[name],
            alpha=alpha,
        )
        sig = "✓" if results[name]["significant"] else "✗"
        logger.info(
            f"  {proposed_name} vs {name}: "
            f"p={results[name]['p_value']:.4f} {sig} | "
            f"d={results[name]['effect_size_d']:.3f}"
        )

    return results


def bootstrap_ci(
    scores     : List[float],
    n_boot     : int   = 10000,
    ci_level   : float = 0.95,
    random_state: int  = 42,
) -> Tuple[float, float]:
    """
    Bootstrap 95% confidence interval for a metric.

    Parameters
    ----------
    scores    : list  Per-subject metric values.
    n_boot    : int   Number of bootstrap replicates.
    ci_level  : float Confidence level (default 0.95).

    Returns
    -------
    (lower, upper) : tuple  CI bounds.
    """
    rng     = np.random.default_rng(random_state)
    scores_ = np.array(scores)
    boots   = rng.choice(scores_, size=(n_boot, len(scores_)), replace=True)
    means   = boots.mean(axis=1)

    alpha   = 1.0 - ci_level
    lower   = np.percentile(means, 100 * alpha / 2)
    upper   = np.percentile(means, 100 * (1 - alpha / 2))

    return float(lower), float(upper)
