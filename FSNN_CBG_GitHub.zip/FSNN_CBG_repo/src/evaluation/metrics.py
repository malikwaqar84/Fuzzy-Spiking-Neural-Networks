"""
metrics.py
──────────
Seizure prediction evaluation metrics.

Implements all metrics from the paper:
  - Sensitivity (True Positive Rate)
  - Specificity (True Negative Rate)
  - Accuracy
  - AUC-ROC
  - False Prediction Rate (FPR/h)
  - Average Prediction Time (APT)
  - Energy Efficiency (mJ/window)
"""

import logging
import numpy as np
from typing import Dict, List, Optional, Tuple

from sklearn.metrics import (
    roc_auc_score,
    confusion_matrix,
    classification_report,
)

logger = logging.getLogger(__name__)


def compute_all_metrics(
    y_true    : np.ndarray,
    y_pred    : np.ndarray,
    y_score   : Optional[np.ndarray] = None,
    recording_hours: float = 0.0,
) -> Dict[str, float]:
    """
    Compute all seizure prediction performance metrics.

    Parameters
    ----------
    y_true           : np.ndarray  True labels (0=interictal, 1=preictal, 2=ictal).
    y_pred           : np.ndarray  Predicted labels.
    y_score          : np.ndarray  Prediction probability scores for pre-ictal class.
    recording_hours  : float       Total recording duration for FPR calculation.

    Returns
    -------
    metrics : dict  All computed metrics.
    """
    # Convert to binary (pre-ictal vs not) for core metrics
    y_bin_true = (y_true == 1).astype(int)
    y_bin_pred = (y_pred == 1).astype(int)

    metrics = {}

    # ── Confusion matrix ────────────────────────────────────────────────
    tn, fp, fn, tp = confusion_matrix(
        y_bin_true, y_bin_pred, labels=[0, 1]
    ).ravel() if len(np.unique(y_bin_true)) > 1 else (
        int((y_bin_true == 0).sum()), 0,
        0, int((y_bin_true == 1).sum())
    )

    # ── Core metrics ────────────────────────────────────────────────────
    metrics["sensitivity"] = tp / (tp + fn + 1e-8)
    metrics["specificity"] = tn / (tn + fp + 1e-8)
    metrics["accuracy"]    = (tp + tn) / (tp + tn + fp + fn + 1e-8)
    metrics["precision"]   = tp / (tp + fp + 1e-8)
    metrics["f1_score"]    = (
        2 * metrics["precision"] * metrics["sensitivity"] /
        (metrics["precision"] + metrics["sensitivity"] + 1e-8)
    )

    # ── AUC-ROC ─────────────────────────────────────────────────────────
    if y_score is not None and len(np.unique(y_bin_true)) > 1:
        try:
            metrics["auc_roc"] = roc_auc_score(y_bin_true, y_score)
        except Exception:
            metrics["auc_roc"] = 0.0
    else:
        metrics["auc_roc"] = 0.0

    # ── False Prediction Rate (FP / hour) ────────────────────────────────
    if recording_hours > 0:
        metrics["fpr_per_hour"] = fp / recording_hours
    else:
        metrics["fpr_per_hour"] = 0.0

    # ── Rounded for reporting ────────────────────────────────────────────
    for k in metrics:
        metrics[k] = float(np.round(metrics[k], 4))

    return metrics


def compute_apt(
    alarm_times  : List[float],
    seizure_times: List[float],
    max_horizon  : float = 1800.0,
) -> Dict[str, float]:
    """
    Compute Average Prediction Time (APT) and related statistics.

    Parameters
    ----------
    alarm_times   : list  Alarm trigger times (absolute seconds).
    seizure_times : list  Seizure onset times (absolute seconds).
    max_horizon   : float Maximum valid prediction horizon (s, default 1800 = 30min).

    Returns
    -------
    dict with: mean_apt_min, median_apt_min, pct_clinically_actionable,
               pct_over_30min, min_apt_min, max_apt_min
    """
    prediction_times = []

    for onset in seizure_times:
        # Find the earliest alarm before this seizure within the horizon
        valid_alarms = [
            onset - t for t in alarm_times
            if 0 < (onset - t) <= max_horizon
        ]
        if valid_alarms:
            prediction_times.append(min(valid_alarms))

    if not prediction_times:
        return {
            "mean_apt_min"             : 0.0,
            "median_apt_min"           : 0.0,
            "pct_clinically_actionable": 0.0,
            "pct_over_30min"           : 0.0,
            "min_apt_min"              : 0.0,
            "max_apt_min"              : 0.0,
        }

    pts_min = np.array(prediction_times) / 60.0

    return {
        "mean_apt_min"             : float(np.mean(pts_min)),
        "median_apt_min"           : float(np.median(pts_min)),
        "pct_clinically_actionable": float((pts_min >= 10).mean() * 100),
        "pct_over_30min"           : float((pts_min >= 30).mean() * 100),
        "min_apt_min"              : float(pts_min.min()),
        "max_apt_min"              : float(pts_min.max()),
    }


def compute_energy_mj(
    spike_counts   : List[int],
    layer_fan_ins  : List[int],
    energy_per_synop_pj: float = 8.6,
) -> float:
    """
    Estimate inference energy using Loihi 2 SynOp model.

    Parameters
    ----------
    spike_counts     : list  Total spikes emitted at each layer.
    layer_fan_ins    : list  Fan-in (input connections) for each layer.
    energy_per_synop : float pJ per synaptic operation (default 8.6).

    Returns
    -------
    energy_mj : float  Energy in millijoules.
    """
    total_synops = sum(s * f for s, f in zip(spike_counts, layer_fan_ins))
    energy_pj    = total_synops * energy_per_synop_pj
    return energy_pj * 1e-9


def print_subject_results(subject_id: int, metrics: Dict):
    """Pretty-print per-subject evaluation results."""
    print(f"\n{'─'*60}")
    print(f"  Subject: chb{subject_id:02d}")
    print(f"{'─'*60}")
    print(f"  Sensitivity     : {metrics.get('sensitivity', 0)*100:.2f}%")
    print(f"  Specificity     : {metrics.get('specificity', 0)*100:.2f}%")
    print(f"  Accuracy        : {metrics.get('accuracy', 0)*100:.2f}%")
    print(f"  AUC-ROC         : {metrics.get('auc_roc', 0)*100:.2f}%")
    print(f"  FPR             : {metrics.get('fpr_per_hour', 0):.3f}/h")
    print(f"  F1-Score        : {metrics.get('f1_score', 0)*100:.2f}%")
    print(f"{'─'*60}\n")


def aggregate_subject_metrics(
    all_metrics: List[Dict],
) -> Dict[str, Tuple[float, float]]:
    """
    Aggregate per-subject metrics across all subjects.

    Returns
    -------
    dict: metric → (mean, std)
    """
    keys = [k for k in all_metrics[0] if isinstance(all_metrics[0][k], float)]
    agg  = {}

    for k in keys:
        vals    = np.array([m[k] for m in all_metrics])
        agg[k]  = (float(vals.mean()), float(vals.std()))

    return agg
