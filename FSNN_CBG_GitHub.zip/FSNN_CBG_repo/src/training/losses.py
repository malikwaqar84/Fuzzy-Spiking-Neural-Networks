"""
losses.py
─────────
Custom loss functions for FSNN-CBG training.

Includes:
  - WeightedFocalLoss: focal loss with class weighting for imbalance
  - SpikeRegularisationLoss: L1 penalty on spike density for sparsity
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from typing import Optional


class WeightedFocalLoss(nn.Module):
    """
    Focal Loss with class-frequency-based weights to handle imbalance.

    FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)

    Parameters
    ----------
    n_classes  : int    Number of output classes.
    gamma      : float  Focusing parameter (default 2.0).
    class_weights : Tensor, optional  Manual class weights.
    """

    def __init__(
        self,
        n_classes    : int,
        gamma        : float = 2.0,
        class_weights: Optional[Tensor] = None,
    ):
        super().__init__()
        self.n_classes    = n_classes
        self.gamma        = gamma
        self.class_weights = class_weights

    def forward(self, probs: Tensor, targets: Tensor) -> Tensor:
        """
        Parameters
        ----------
        probs   : Tensor  (batch, n_classes) — softmax probabilities.
        targets : Tensor  (batch,) — integer class labels.

        Returns
        -------
        loss : Tensor  scalar
        """
        # Cross-entropy component
        log_probs = torch.log(probs.clamp(min=1e-8))
        ce_loss   = F.nll_loss(log_probs, targets, weight=self.class_weights,
                               reduction="none")

        # Focal weight
        pt            = probs.gather(1, targets.unsqueeze(1)).squeeze(1)
        focal_weight  = (1.0 - pt) ** self.gamma

        return (focal_weight * ce_loss).mean()


class SpikeRegularisationLoss(nn.Module):
    """
    L1 regularisation on spike density to encourage sparse SNN activity.
    Minimises total synaptic operations → energy reduction.

    Parameters
    ----------
    lambda_reg : float  Regularisation strength (default 1e-4).
    """

    def __init__(self, lambda_reg: float = 1e-4):
        super().__init__()
        self.lambda_reg = lambda_reg

    def forward(self, spike_density: Tensor) -> Tensor:
        """
        Parameters
        ----------
        spike_density : Tensor  (batch, n_neurons) — average firing rates.

        Returns
        -------
        reg_loss : Tensor  scalar
        """
        return self.lambda_reg * spike_density.abs().mean()


class ContrastiveLoss(nn.Module):
    """
    Contrastive loss to maximise inter-class embedding distance.
    Encourages pre-ictal and interictal features to be well-separated.

    Parameters
    ----------
    margin : float  Minimum inter-class margin (default 1.0).
    """

    def __init__(self, margin: float = 1.0):
        super().__init__()
        self.margin = margin

    def forward(
        self,
        embeddings : Tensor,
        labels     : Tensor,
    ) -> Tensor:
        """
        Parameters
        ----------
        embeddings : Tensor  (batch, dim)
        labels     : Tensor  (batch,)
        """
        B    = embeddings.shape[0]
        dist = torch.cdist(embeddings, embeddings, p=2)

        same_class = (labels.unsqueeze(0) == labels.unsqueeze(1)).float()

        # Positive pairs: same class → minimise distance
        pos_loss = same_class * dist.pow(2)

        # Negative pairs: different class → push apart by margin
        neg_loss = (1 - same_class) * F.relu(self.margin - dist).pow(2)

        return (pos_loss + neg_loss).mean() / (B * (B - 1) + 1)
