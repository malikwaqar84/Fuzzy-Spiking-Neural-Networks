"""
trainer.py
──────────
Main FSNN-CBG training loop.

Handles:
  - Joint SNN encoder + STGCN training
  - IT2FLS training on frozen embeddings
  - Validation, checkpointing, early stopping
  - TensorBoard logging
"""

import os
import logging
import time
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from src.models.snn_encoder import SNNEncoder
from src.models.stgcn import STGCNEncoder
from src.models.it2_fuzzy import IT2FuzzyClassifier
from src.training.losses import WeightedFocalLoss
from src.evaluation.metrics import compute_all_metrics

logger = logging.getLogger(__name__)


class FSNNCBGTrainer:
    """
    End-to-end trainer for the FSNN-CBG framework.

    Parameters
    ----------
    snn_encoder  : SNNEncoder
    stgcn        : STGCNEncoder
    fuzzy_clf    : IT2FuzzyClassifier
    config       : dict   Training configuration (from config.yaml).
    device       : str    'cuda' or 'cpu'.
    log_dir      : str    TensorBoard log directory.
    ckpt_dir     : str    Checkpoint save directory.
    """

    def __init__(
        self,
        snn_encoder  : SNNEncoder,
        stgcn        : STGCNEncoder,
        fuzzy_clf    : IT2FuzzyClassifier,
        config       : Dict,
        device       : str = "cuda",
        log_dir      : str = "logs/",
        ckpt_dir     : str = "checkpoints/",
    ):
        self.device      = torch.device(device if torch.cuda.is_available() else "cpu")
        self.config      = config
        self.log_dir     = Path(log_dir)
        self.ckpt_dir    = Path(ckpt_dir)

        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.ckpt_dir.mkdir(parents=True, exist_ok=True)

        # Models
        self.snn   = snn_encoder.to(self.device)
        self.stgcn = stgcn.to(self.device)
        self.fuzzy = fuzzy_clf.to(self.device)

        # Loss
        self.criterion = WeightedFocalLoss(
            n_classes=config.get("n_classes", 3),
            gamma=config.get("focal_gamma", 2.0),
        ).to(self.device)

        # Optimisers
        snn_cfg   = config.get("snn", {})
        stgcn_cfg = config.get("causal_graph", {})
        it2_cfg   = config.get("it2_fuzzy", {})

        self.opt_snn = torch.optim.Adam(
            list(self.snn.parameters()),
            lr=snn_cfg.get("lr", 1e-3),
            weight_decay=snn_cfg.get("weight_decay", 1e-5),
        )
        self.opt_stgcn = torch.optim.Adam(
            list(self.stgcn.parameters()),
            lr=stgcn_cfg.get("lr", 5e-4),
            weight_decay=stgcn_cfg.get("weight_decay", 1e-5),
        )
        self.opt_fuzzy = torch.optim.Adam(
            list(self.fuzzy.parameters()),
            lr=it2_cfg.get("lr", 1e-3),
        )

        # Schedulers
        self.sch_snn = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.opt_snn,
            T_max=snn_cfg.get("epochs", 100),
            eta_min=1e-6,
        )
        self.sch_stgcn = torch.optim.lr_scheduler.StepLR(
            self.opt_stgcn,
            step_size=stgcn_cfg.get("step_size", 20),
            gamma=stgcn_cfg.get("gamma", 0.5),
        )

        # TensorBoard
        self.writer = SummaryWriter(log_dir=str(self.log_dir))

        # Early stopping state
        self.best_val_metric = 0.0
        self.patience_counter = 0

        logger.info(f"FSNNCBGTrainer initialised on {self.device}")

    # ── Phase 1: Joint SNN + STGCN training ─────────────────────────────────

    def train_backbone(
        self,
        train_loader : DataLoader,
        val_loader   : DataLoader,
        n_epochs     : int = 100,
        patience     : int = 15,
        subject_id   : int = 0,
    ) -> Dict:
        """
        Train the SNN encoder and STGCN jointly.

        Parameters
        ----------
        train_loader : DataLoader   Training data.
        val_loader   : DataLoader   Validation data.
        n_epochs     : int          Max training epochs.
        patience     : int          Early stopping patience.
        subject_id   : int          Subject ID for logging.

        Returns
        -------
        history : dict  Training history (loss, metrics).
        """
        history = {"train_loss": [], "val_loss": [], "val_sensitivity": []}
        tag = f"subj{subject_id:02d}"

        for epoch in range(1, n_epochs + 1):
            t0 = time.time()

            # ── Train ─────────────────────────────────────────────────────
            self.snn.train()
            self.stgcn.train()
            self.fuzzy.eval()

            train_loss, train_metrics = self._run_epoch(
                train_loader, phase="train"
            )

            # ── Validate ──────────────────────────────────────────────────
            self.snn.eval()
            self.stgcn.eval()

            with torch.no_grad():
                val_loss, val_metrics = self._run_epoch(
                    val_loader, phase="val"
                )

            self.sch_snn.step()
            self.sch_stgcn.step()

            # ── Logging ───────────────────────────────────────────────────
            elapsed = time.time() - t0
            logger.info(
                f"[{tag}] Epoch {epoch:3d}/{n_epochs} | "
                f"Train Loss: {train_loss:.4f} | "
                f"Val Loss: {val_loss:.4f} | "
                f"Val Sen: {val_metrics.get('sensitivity', 0):.4f} | "
                f"Val Spe: {val_metrics.get('specificity', 0):.4f} | "
                f"t={elapsed:.1f}s"
            )

            self.writer.add_scalar(f"{tag}/train_loss", train_loss, epoch)
            self.writer.add_scalar(f"{tag}/val_loss",   val_loss,   epoch)
            for k, v in val_metrics.items():
                self.writer.add_scalar(f"{tag}/val_{k}", v, epoch)

            history["train_loss"].append(train_loss)
            history["val_loss"].append(val_loss)
            history["val_sensitivity"].append(val_metrics.get("sensitivity", 0))

            # ── Early stopping & checkpointing ────────────────────────────
            val_sen = val_metrics.get("sensitivity", 0)
            if val_sen > self.best_val_metric:
                self.best_val_metric  = val_sen
                self.patience_counter = 0
                self._save_checkpoint(epoch, val_sen, tag, "best")
            else:
                self.patience_counter += 1

            if self.patience_counter >= patience:
                logger.info(
                    f"[{tag}] Early stopping triggered at epoch {epoch}"
                )
                break

        return history

    # ── Phase 2: IT2FLS training on frozen embeddings ───────────────────────

    def train_fuzzy(
        self,
        train_loader : DataLoader,
        val_loader   : DataLoader,
        n_epochs     : int = 50,
        subject_id   : int = 0,
    ) -> Dict:
        """
        Fine-tune the IT2FLS on frozen SNN + STGCN embeddings.
        """
        # Freeze backbone
        for p in self.snn.parameters():
            p.requires_grad = False
        for p in self.stgcn.parameters():
            p.requires_grad = False

        history = {"train_loss": [], "val_sensitivity": []}
        tag = f"fuzzy_subj{subject_id:02d}"

        for epoch in range(1, n_epochs + 1):
            self.fuzzy.train()

            train_loss = self._run_fuzzy_epoch(train_loader, phase="train")

            self.fuzzy.eval()
            with torch.no_grad():
                _, val_metrics = self._run_epoch(val_loader, phase="val")

            val_sen = val_metrics.get("sensitivity", 0)
            self.writer.add_scalar(f"{tag}/train_loss", train_loss, epoch)
            self.writer.add_scalar(f"{tag}/val_sensitivity", val_sen, epoch)

            history["train_loss"].append(train_loss)
            history["val_sensitivity"].append(val_sen)

            if epoch % 10 == 0:
                logger.info(
                    f"[{tag}] Epoch {epoch:3d}/{n_epochs} | "
                    f"Loss: {train_loss:.4f} | Val Sen: {val_sen:.4f}"
                )

        # Unfreeze
        for p in self.snn.parameters():
            p.requires_grad = True
        for p in self.stgcn.parameters():
            p.requires_grad = True

        return history

    # ── Private ─────────────────────────────────────────────────────────────

    def _run_epoch(
        self,
        loader : DataLoader,
        phase  : str,
    ) -> Tuple[float, Dict]:
        """Run one full epoch (train or val)."""
        total_loss = 0.0
        all_preds  = []
        all_labels = []

        for batch in loader:
            eeg, labels = batch
            eeg    = eeg.to(self.device)
            labels = labels.to(self.device)

            # Forward: SNN features
            f_snn = self.snn(eeg)

            # For simplicity: use SNN features directly as STGCN input
            # (Full version computes graph embeddings separately)
            # Combined feature: repeat f_snn to match expected dim 96
            if f_snn.shape[-1] < 96:
                pad = torch.zeros(
                    f_snn.shape[0], 96 - f_snn.shape[-1],
                    device=self.device
                )
                f_combined = torch.cat([f_snn, pad], dim=-1)
            else:
                f_combined = f_snn[:, :96]

            # IT2FLS classification
            probs = self.fuzzy(f_combined)
            loss  = self.criterion(probs, labels)

            if phase == "train":
                self.opt_snn.zero_grad()
                self.opt_stgcn.zero_grad()
                self.opt_fuzzy.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    list(self.snn.parameters()), max_norm=1.0
                )
                self.opt_snn.step()
                self.opt_fuzzy.step()

            total_loss += loss.item() * eeg.size(0)
            preds       = probs.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())

        avg_loss = total_loss / max(len(loader.dataset), 1)
        metrics  = compute_all_metrics(
            np.array(all_labels), np.array(all_preds)
        )
        return avg_loss, metrics

    def _run_fuzzy_epoch(
        self,
        loader : DataLoader,
        phase  : str,
    ) -> float:
        """Train IT2FLS only (backbone frozen)."""
        total_loss = 0.0

        for batch in loader:
            eeg, labels = batch
            eeg    = eeg.to(self.device)
            labels = labels.to(self.device)

            with torch.no_grad():
                f_snn = self.snn(eeg)
                if f_snn.shape[-1] < 96:
                    pad = torch.zeros(
                        f_snn.shape[0], 96 - f_snn.shape[-1],
                        device=self.device
                    )
                    f_combined = torch.cat([f_snn, pad], dim=-1)
                else:
                    f_combined = f_snn[:, :96]

            probs = self.fuzzy(f_combined)
            loss  = self.criterion(probs, labels)

            self.opt_fuzzy.zero_grad()
            loss.backward()
            self.opt_fuzzy.step()

            total_loss += loss.item() * eeg.size(0)

        return total_loss / max(len(loader.dataset), 1)

    def _save_checkpoint(
        self,
        epoch    : int,
        metric   : float,
        tag      : str,
        suffix   : str = "best",
    ):
        ckpt_path = self.ckpt_dir / f"{tag}_{suffix}.pt"
        torch.save({
            "epoch"       : epoch,
            "metric"      : metric,
            "snn_state"   : self.snn.state_dict(),
            "stgcn_state" : self.stgcn.state_dict(),
            "fuzzy_state" : self.fuzzy.state_dict(),
            "opt_snn"     : self.opt_snn.state_dict(),
        }, ckpt_path)
        logger.debug(f"Checkpoint saved: {ckpt_path} (val_sen={metric:.4f})")

    def load_checkpoint(self, path: str):
        ckpt = torch.load(path, map_location=self.device)
        self.snn.load_state_dict(ckpt["snn_state"])
        self.stgcn.load_state_dict(ckpt["stgcn_state"])
        self.fuzzy.load_state_dict(ckpt["fuzzy_state"])
        logger.info(f"Checkpoint loaded: {path}")
