"""
download_chbmit.py
──────────────────
Helper script to download the CHB-MIT Scalp EEG Database from PhysioNet.

Usage:
  python scripts/download_chbmit.py --output_dir data/chbmit
  python scripts/download_chbmit.py --output_dir data/chbmit --subjects 1 2 3

Requires wget or PhysioNet credentials for restricted-access files.
The CHB-MIT dataset is freely available at:
  https://physionet.org/content/chbmit/1.0.0/
"""

import argparse
import os
import subprocess
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(message)s")
logger = logging.getLogger(__name__)

PHYSIONET_BASE = "https://physionet.org/files/chbmit/1.0.0/"


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--output_dir", type=str, default="data/chbmit",
                   help="Directory to save downloaded files.")
    p.add_argument("--subjects", nargs="+", type=int, default=list(range(1, 25)),
                   help="Subject IDs to download (1-24).")
    p.add_argument("--username", type=str, default="",
                   help="PhysioNet username (if required).")
    p.add_argument("--password", type=str, default="",
                   help="PhysioNet password (if required).")
    return p.parse_args()


def download_subject(
    subject_id : int,
    output_dir : Path,
    username   : str = "",
    password   : str = "",
):
    subject_str = f"chb{subject_id:02d}"
    subject_dir = output_dir / subject_str
    subject_dir.mkdir(parents=True, exist_ok=True)

    url = f"{PHYSIONET_BASE}{subject_str}/"

    # Use wget with recursive download
    cmd = [
        "wget", "-r", "-N", "-c", "-np",
        "--directory-prefix", str(output_dir),
        "--no-host-directories",
        "--cut-dirs=3",
    ]

    if username and password:
        cmd += [f"--user={username}", f"--password={password}"]

    cmd.append(url)

    logger.info(f"Downloading {subject_str}...")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            logger.info(f"  ✓ {subject_str} downloaded")
        else:
            logger.warning(f"  ✗ {subject_str} download returned {result.returncode}")
            logger.debug(result.stderr)
    except FileNotFoundError:
        logger.error(
            "wget not found. Please install wget or download manually from:\n"
            f"  {PHYSIONET_BASE}"
        )


def verify_download(output_dir: Path, subject_id: int) -> bool:
    """Check that at least one .edf file exists for the subject."""
    subject_dir = output_dir / f"chb{subject_id:02d}"
    edf_files   = list(subject_dir.glob("*.edf"))
    if edf_files:
        logger.info(f"  chb{subject_id:02d}: {len(edf_files)} .edf files found")
        return True
    else:
        logger.warning(f"  chb{subject_id:02d}: no .edf files found")
        return False


def main():
    args       = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info(
        f"CHB-MIT Download\n"
        f"  Output: {output_dir}\n"
        f"  Subjects: {args.subjects}\n"
        f"  Source: {PHYSIONET_BASE}"
    )

    for sid in args.subjects:
        download_subject(sid, output_dir, args.username, args.password)

    # Verify
    logger.info("\nVerification:")
    ok_count = sum(verify_download(output_dir, sid) for sid in args.subjects)
    logger.info(f"\n{ok_count}/{len(args.subjects)} subjects verified successfully.")

    if ok_count < len(args.subjects):
        logger.warning(
            "\nSome downloads may have failed. You can also download manually:\n"
            "  1. Visit https://physionet.org/content/chbmit/1.0.0/\n"
            "  2. Create a free account\n"
            "  3. Download chb01/ through chb24/ folders\n"
            f"  4. Place them in: {output_dir}/"
        )


if __name__ == "__main__":
    main()
