"""
train.py
────────
Training entry point for FSNN-CBG.

Usage:
  python scripts/train.py --config configs/config.yaml --subject all
  python scripts/train.py --config configs/config.yaml --subject 1
  python scripts/train.py --config configs/config.yaml --subject 1 2 3
"""

import argparse
import logging
import sys
import os
import yaml
import torch
import numpy as np
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.preprocessing.loader     import CHBMITLoader
from src.preprocessing.filters    import EEGFilterPipeline
from src.preprocessing.ica        import ICAArtefactRemover
from src.preprocessing.segmentation import WindowExtractor, EEGWindowDataset
from src.preprocessing.augmentation import smote_balance
from src.models.snn_encoder        import SNNEncoder
from src.models.stgcn              import STGCNEncoder
from src.models.it2_fuzzy          import IT2FuzzyClassifier
from src.training.trainer          import FSNNCBGTrainer
from src.evaluation.metrics        import compute_all_metrics, print_subject_results

from torch.utils.data import DataLoader, random_split

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="Train FSNN-CBG on CHB-MIT")
    p.add_argument("--config",  type=str, default="configs/config.yaml")
    p.add_argument("--subject", nargs="+", default=["all"],
                   help="Subject IDs to train on (e.g. 1 2 3 or 'all')")
    p.add_argument("--device",  type=str, default=None,
                   help="Override device: 'cuda' or 'cpu'")
    p.add_argument("--seed",    type=int, default=42)
    return p.parse_args()


def set_seed(seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def build_models(config: dict):
    snn_cfg   = config.get("snn", {})
    stgcn_cfg = config.get("causal_graph", {})
    it2_cfg   = config.get("it2_fuzzy", {})
    ds_cfg    = config.get("dataset", {})

    snn = SNNEncoder(
        in_channels  = ds_cfg.get("n_channels", 23),
        hidden_sizes = snn_cfg.get("architecture", [256, 128, 64]),
        out_dim      = snn_cfg.get("output_dim", 64),
        tau_m_ms     = snn_cfg.get("tau_m", 20.0),
        v_threshold  = snn_cfg.get("v_threshold", 1.0),
        beta_sg      = snn_cfg.get("surrogate_beta", 10.0),
        r_max        = snn_cfg.get("r_max", 100.0),
        wta_k        = snn_cfg.get("wta_k", 10),
        dropout      = snn_cfg.get("dropout", 0.3),
    )

    stgcn = STGCNEncoder(
        node_features = 5,
        n_nodes       = ds_cfg.get("n_channels", 23),
        hidden_dims   = stgcn_cfg.get("gcn_dims", [64, 32]),
        out_dim       = stgcn_cfg.get("output_dim", 32),
        temporal_k    = stgcn_cfg.get("temporal_kernel", 3),
        dropout       = stgcn_cfg.get("dropout", 0.4),
    )

    fuzzy = IT2FuzzyClassifier(
        input_dim   = it2_cfg.get("input_dim", 96),
        n_classes   = it2_cfg.get("n_classes", 3),
        n_rules     = it2_cfg.get("n_rules", 15),
        sigma_lower = it2_cfg.get("sigma_lower_scale", 0.8),
        sigma_upper = it2_cfg.get("sigma_upper_scale", 1.2),
    )

    return snn, stgcn, fuzzy


def prepare_data_loaders(
    subject_id : int,
    config     : dict,
) -> tuple:
    """Load, preprocess, and return train/val/test DataLoaders."""

    ds_cfg  = config.get("dataset",       {})
    pp_cfg  = config.get("preprocessing", {})
    seg_cfg = config.get("segmentation",  {})

    # 1. Load raw EEG
    loader = CHBMITLoader(
        root_dir     = ds_cfg.get("root_dir", "data/chbmit"),
        subjects     = [subject_id],
        preictal_min = seg_cfg.get("preictal_min", 30.0),
    )
    subject_data = loader.load_subject(subject_id)

    if not subject_data["raw"]:
        raise RuntimeError(f"No EEG files loaded for subject {subject_id}")

    # 2. Filter pipeline
    pipeline = EEGFilterPipeline(
        notch_freq   = pp_cfg.get("notch_freq", 50.0),
        bp_low       = pp_cfg.get("bandpass_low", 0.5),
        bp_high      = pp_cfg.get("bandpass_high", 40.0),
        apply_car    = pp_cfg.get("car", {}).get("enabled", True),
        apply_zscore = True,
    )

    # 3. ICA
    ica = ICAArtefactRemover(
        n_components  = pp_cfg.get("ica", {}).get("n_components", 23),
        eog_threshold = pp_cfg.get("ica", {}).get("eog_threshold", 0.8),
    )

    # 4. Segment
    extractor = WindowExtractor(
        window_sec       = seg_cfg.get("window_sec", 5.0),
        overlap          = seg_cfg.get("overlap", 0.0),
        preictal_min     = seg_cfg.get("preictal_min", 30.0),
        interictal_gap_h = seg_cfg.get("interictal_gap_h", 4.0),
        sfreq            = ds_cfg.get("sampling_rate", 256),
    )

    all_windows, all_labels = [], []

    for raw_obj, file_path in zip(
        subject_data["raw"], subject_data["file_paths"]
    ):
        raw_obj = pipeline.process(raw_obj)
        if pp_cfg.get("ica", {}).get("enabled", True):
            try:
                raw_obj = ica.fit_transform(raw_obj)
            except Exception as e:
                logger.warning(f"ICA failed for {file_path.name}: {e}")

        data = raw_obj.get_data()   # (C, T)
        annotations = [
            a for a in subject_data["annotations"]
            if a.file_name == file_path.name
        ]

        windows, labels = extractor.extract(data, annotations)
        if len(windows) > 0:
            all_windows.append(windows)
            all_labels.append(labels)

    if not all_windows:
        raise RuntimeError(f"No windows extracted for subject {subject_id}")

    X = np.concatenate(all_windows, axis=0)
    y = np.concatenate(all_labels,  axis=0)

    # 5. SMOTE
    smote_cfg = seg_cfg.get("smote", {})
    if smote_cfg.get("enabled", True):
        X, y = smote_balance(
            X, y,
            target_ratio = smote_cfg.get("ratio", 0.25),
            k_neighbors  = smote_cfg.get("k_neighbors", 5),
        )

    # 6. Split
    dataset    = EEGWindowDataset(X, y, subject_ids=[subject_id]*len(y))
    n          = len(dataset)
    split      = ds_cfg.get("split", {"train":0.7,"val":0.1,"test":0.2})
    n_train    = int(n * split["train"])
    n_val      = int(n * split["val"])
    n_test     = n - n_train - n_val

    train_ds, val_ds, test_ds = random_split(
        dataset, [n_train, n_val, n_test],
        generator=torch.Generator().manual_seed(42)
    )

    bs = config.get("snn", {}).get("batch_size", 64)

    train_loader = DataLoader(train_ds, batch_size=bs, shuffle=True,  num_workers=2)
    val_loader   = DataLoader(val_ds,   batch_size=bs, shuffle=False, num_workers=2)
    test_loader  = DataLoader(test_ds,  batch_size=bs, shuffle=False, num_workers=2)

    logger.info(
        f"Subject chb{subject_id:02d} | "
        f"Train: {n_train} | Val: {n_val} | Test: {n_test}"
    )
    return train_loader, val_loader, test_loader


def train_subject(subject_id: int, config: dict, device: str):
    """Full training pipeline for one subject."""
    logger.info(f"\n{'='*60}\n  Training Subject chb{subject_id:02d}\n{'='*60}")

    # Build models
    snn, stgcn, fuzzy = build_models(config)

    # Data
    train_loader, val_loader, test_loader = prepare_data_loaders(
        subject_id, config
    )

    # Trainer
    trainer = FSNNCBGTrainer(
        snn_encoder = snn,
        stgcn       = stgcn,
        fuzzy_clf   = fuzzy,
        config      = config,
        device      = device,
        log_dir     = os.path.join(config["experiment"]["log_dir"],
                                   f"subj{subject_id:02d}"),
        ckpt_dir    = config["experiment"]["checkpoint_dir"],
    )

    # Phase 1: Train backbone
    snn_cfg = config.get("snn", {})
    history = trainer.train_backbone(
        train_loader = train_loader,
        val_loader   = val_loader,
        n_epochs     = snn_cfg.get("epochs", 100),
        patience     = config["logging"]["early_stopping"].get("patience", 15),
        subject_id   = subject_id,
    )

    # Phase 2: Fine-tune IT2FLS
    it2_cfg = config.get("it2_fuzzy", {})
    trainer.train_fuzzy(
        train_loader = train_loader,
        val_loader   = val_loader,
        n_epochs     = it2_cfg.get("epochs", 50),
        subject_id   = subject_id,
    )

    # Final evaluation on test set
    trainer.snn.eval()
    trainer.fuzzy.eval()

    all_preds, all_labels = [], []
    with torch.no_grad():
        for eeg, labels in test_loader:
            eeg    = eeg.to(trainer.device)
            f_snn  = trainer.snn(eeg)
            if f_snn.shape[-1] < 96:
                pad = torch.zeros(f_snn.shape[0], 96 - f_snn.shape[-1],
                                  device=trainer.device)
                f_combined = torch.cat([f_snn, pad], dim=-1)
            else:
                f_combined = f_snn[:, :96]
            probs  = trainer.fuzzy(f_combined)
            preds  = probs.argmax(dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.numpy())

    metrics = compute_all_metrics(
        np.array(all_labels), np.array(all_preds)
    )
    print_subject_results(subject_id, metrics)
    return metrics


def main():
    args   = parse_args()
    config = load_config(args.config)

    set_seed(args.seed or config["experiment"].get("seed", 42))

    device = args.device or config["experiment"].get("device", "cuda")
    if not torch.cuda.is_available() and device == "cuda":
        logger.warning("CUDA not available, falling back to CPU")
        device = "cpu"

    # Determine subjects
    subjects_arg = args.subject
    if subjects_arg == ["all"] or subjects_arg == "all":
        subjects = list(range(1, 25))
    else:
        subjects = [int(s) for s in subjects_arg]

    logger.info(
        f"FSNN-CBG Training | device={device} | "
        f"subjects={subjects} | seed={args.seed}"
    )

    # Train each subject
    all_metrics = []
    for sid in subjects:
        try:
            metrics = train_subject(sid, config, device)
            all_metrics.append(metrics)
        except Exception as e:
            logger.error(f"Failed subject {sid}: {e}", exc_info=True)

    # Print aggregated results
    if all_metrics:
        import pandas as pd
        df = pd.DataFrame(all_metrics)
        print("\n" + "="*60)
        print("  AGGREGATE RESULTS")
        print("="*60)
        print(df.describe().round(4).to_string())


if __name__ == "__main__":
    main()
