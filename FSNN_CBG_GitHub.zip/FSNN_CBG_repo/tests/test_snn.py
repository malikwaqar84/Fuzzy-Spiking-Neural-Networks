"""
test_snn.py
───────────
Unit tests for SNN encoder components.
"""

import pytest
import torch
import numpy as np

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models.lif_neuron  import LIFLayer, PoissonEncoder, winner_take_all
from src.models.snn_encoder import SNNEncoder


class TestLIFNeuron:

    def test_lif_output_shape(self):
        lif   = LIFLayer(in_features=23, out_features=256)
        x     = torch.randn(8, 23)
        spike, membrane = lif(x)
        assert spike.shape    == (8, 256), f"Expected (8,256), got {spike.shape}"
        assert membrane.shape == (8, 256)

    def test_spike_binary(self):
        lif   = LIFLayer(in_features=23, out_features=256)
        x     = torch.randn(4, 23)
        spike, _ = lif(x)
        assert torch.all((spike == 0) | (spike == 1)), "Spikes must be binary {0,1}"

    def test_membrane_stateful(self):
        """Membrane at t+1 should differ from initial state."""
        lif   = LIFLayer(in_features=10, out_features=20)
        x     = torch.randn(2, 10)
        _, m0 = lif(x, membrane=None)
        _, m1 = lif(x, membrane=m0)
        assert not torch.allclose(m0, m1), "Membrane should update across time steps"

    def test_surrogate_gradient_flows(self):
        """Gradients should flow through the surrogate spike function."""
        lif   = LIFLayer(in_features=10, out_features=20)
        x     = torch.randn(2, 10, requires_grad=True)
        spike, _ = lif(x)
        loss  = spike.sum()
        loss.backward()
        assert x.grad is not None, "Gradient should flow through LIF layer"
        assert not torch.isnan(x.grad).any(), "No NaN gradients"


class TestPoissonEncoder:

    def test_output_shape(self):
        enc    = PoissonEncoder(n_steps=100, r_max=100.0)
        x      = torch.rand(4, 23, 1280)   # (batch, channels, samples)
        spikes = enc(x)
        assert spikes.shape[0] == 4
        assert spikes.shape[1] == 23

    def test_spike_values_binary(self):
        enc    = PoissonEncoder(n_steps=50)
        x      = torch.rand(2, 5, 1280)
        spikes = enc(x)
        assert torch.all((spikes == 0) | (spikes == 1))

    def test_zero_input_low_rate(self):
        """Near-zero input should produce sparse spikes."""
        enc    = PoissonEncoder(n_steps=1000)
        x      = torch.zeros(1, 5, 1000) + 0.001
        spikes = enc(x)
        mean_rate = spikes.float().mean().item()
        assert mean_rate < 0.01, f"Low input should → low rate, got {mean_rate:.4f}"


class TestWinnerTakeAll:

    def test_wta_k_winners(self):
        x      = torch.rand(4, 64)
        k      = 10
        result = winner_take_all(x, k=k)
        # Each sample should have exactly k non-zero values
        for i in range(4):
            n_active = (result[i] > 0).sum().item()
            assert n_active <= k, f"WTA should keep ≤{k} winners, got {n_active}"

    def test_wta_preserves_values(self):
        x      = torch.rand(2, 10)
        result = winner_take_all(x, k=5)
        # Non-zero values should match original
        mask   = result > 0
        assert torch.allclose(result[mask], x[mask])


class TestSNNEncoder:

    def test_forward_shape(self):
        snn  = SNNEncoder(in_channels=23, hidden_sizes=[64, 32, 16], out_dim=16)
        x    = torch.rand(4, 23, 256)   # small for speed
        feat = snn(x)
        assert feat.shape == (4, 16), f"Expected (4,16), got {feat.shape}"

    def test_output_not_nan(self):
        snn  = SNNEncoder(in_channels=5, hidden_sizes=[32, 16], out_dim=8)
        x    = torch.rand(2, 5, 128)
        feat = snn(x)
        assert not torch.isnan(feat).any(), "SNN output should not contain NaN"

    def test_gradient_backprop(self):
        snn  = SNNEncoder(in_channels=5, hidden_sizes=[16], out_dim=8)
        x    = torch.rand(2, 5, 64, requires_grad=True)
        feat = snn(x)
        loss = feat.sum()
        loss.backward()
        # Check at least one parameter has gradient
        has_grad = any(
            p.grad is not None and not torch.isnan(p.grad).any()
            for p in snn.parameters() if p.requires_grad
        )
        assert has_grad, "SNN parameters should receive gradients"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
