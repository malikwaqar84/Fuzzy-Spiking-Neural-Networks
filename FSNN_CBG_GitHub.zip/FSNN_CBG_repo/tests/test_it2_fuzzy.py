"""
test_it2_fuzzy.py
─────────────────
Unit tests for IT2 Fuzzy Logic Classifier.
"""

import pytest
import torch
import numpy as np

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models.it2_fuzzy import GaussianIT2MF, IT2FuzzyClassifier


class TestGaussianIT2MF:

    def test_output_shape(self):
        mf    = GaussianIT2MF(n_features=96, n_rules=15)
        x     = torch.randn(8, 96)
        mu_L, mu_U = mf(x)
        assert mu_L.shape == (8, 15)
        assert mu_U.shape == (8, 15)

    def test_lower_leq_upper(self):
        """Lower MF values must always be ≤ Upper MF values."""
        mf    = GaussianIT2MF(n_features=96, n_rules=15)
        x     = torch.randn(16, 96)
        mu_L, mu_U = mf(x)
        assert torch.all(mu_L <= mu_U + 1e-6), \
            "Lower MF must be ≤ Upper MF (FOU constraint)"

    def test_mf_values_in_range(self):
        """Membership degrees must be in [0, 1]."""
        mf    = GaussianIT2MF(n_features=10, n_rules=5)
        x     = torch.randn(8, 10) * 5
        mu_L, mu_U = mf(x)
        assert mu_L.min() >= 0.0 and mu_L.max() <= 1.0
        assert mu_U.min() >= 0.0 and mu_U.max() <= 1.0


class TestIT2FuzzyClassifier:

    def test_output_shape(self):
        clf   = IT2FuzzyClassifier(input_dim=96, n_classes=3, n_rules=15)
        x     = torch.randn(8, 96)
        probs = clf(x)
        assert probs.shape == (8, 3), f"Expected (8,3), got {probs.shape}"

    def test_probabilities_sum_to_one(self):
        clf   = IT2FuzzyClassifier(input_dim=96, n_classes=3, n_rules=15)
        x     = torch.randn(16, 96)
        probs = clf(x)
        sums  = probs.sum(dim=1)
        assert torch.allclose(sums, torch.ones(16), atol=1e-5), \
            "Class probabilities must sum to 1"

    def test_probabilities_non_negative(self):
        clf   = IT2FuzzyClassifier(input_dim=96, n_classes=3, n_rules=15)
        x     = torch.randn(8, 96)
        probs = clf(x)
        assert probs.min() >= 0.0, "Probabilities must be non-negative"

    def test_preictal_probability(self):
        clf   = IT2FuzzyClassifier(input_dim=96, n_classes=3, n_rules=15)
        x     = torch.randn(4, 96)
        prob  = clf.predict_preictal_prob(x)
        assert prob.shape == (4,)
        assert prob.min() >= 0.0 and prob.max() <= 1.0

    def test_gradient_flows(self):
        clf   = IT2FuzzyClassifier(input_dim=32, n_classes=3, n_rules=5)
        x     = torch.randn(4, 32, requires_grad=True)
        probs = clf(x)
        loss  = -probs[:, 1].log().mean()
        loss.backward()
        assert x.grad is not None
        assert not torch.isnan(x.grad).any()

    def test_ekm_convergence(self):
        """EKM should produce stable outputs with consistent inputs."""
        clf   = IT2FuzzyClassifier(input_dim=16, n_classes=3, n_rules=5)
        clf.eval()
        x     = torch.ones(4, 16)
        with torch.no_grad():
            p1 = clf(x)
            p2 = clf(x)
        assert torch.allclose(p1, p2), "EKM should be deterministic"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
