"""
test_causal_graph.py
────────────────────
Unit tests for Granger Causality Brain Graph construction.
"""

import pytest
import numpy as np

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.models.causal_graph import GrangerCausalityGraph, normalise_adjacency
from src.preprocessing.filters import extract_band_powers


class TestGrangerCausalityGraph:

    @pytest.fixture
    def small_epoch(self):
        """5-channel, 5-second epoch at 256 Hz."""
        np.random.seed(42)
        return np.random.randn(5, 256 * 5)

    @pytest.fixture
    def gcg(self):
        return GrangerCausalityGraph(sfreq=256.0, max_order=5, min_order=2)

    def test_adjacency_shape(self, gcg, small_epoch):
        adj, feats = gcg.build_graph(small_epoch)
        n = small_epoch.shape[0]
        assert adj.shape   == (n, n), f"Expected ({n},{n}), got {adj.shape}"
        assert feats.shape == (n, 5), f"Expected ({n},5), got {feats.shape}"

    def test_adjacency_non_negative(self, gcg, small_epoch):
        adj, _ = gcg.build_graph(small_epoch)
        assert adj.min() >= 0, "F-statistics must be non-negative"

    def test_diagonal_zero(self, gcg, small_epoch):
        """Self-causality diagonal should be zero."""
        adj, _ = gcg.build_graph(small_epoch)
        assert np.all(np.diag(adj) == 0), "Diagonal must be zero (no self-causality)"

    def test_node_features_positive(self, gcg, small_epoch):
        """Band powers must be non-negative."""
        _, feats = gcg.build_graph(small_epoch)
        assert feats.min() >= 0, "Band powers must be non-negative"

    def test_stationarity_correction(self):
        """Non-stationary signal (linear trend) should be differenced."""
        gcg  = GrangerCausalityGraph(sfreq=256.0, max_order=3, min_order=1)
        t    = np.linspace(0, 1, 256 * 5)
        data = np.stack([t + np.random.randn(len(t)) * 0.1 for _ in range(3)])
        # Should not raise
        adj, feats = gcg.build_graph(data)
        assert adj.shape == (3, 3)

    def test_edge_index_format(self, gcg, small_epoch):
        adj, _      = gcg.build_graph(small_epoch)
        edge_index, edge_weight = gcg.adjacency_to_edge_index(adj, threshold=0.0)
        assert edge_index.shape[0]  == 2
        assert edge_weight.shape[0] == edge_index.shape[1]
        assert edge_weight.min()    >= 0.0


class TestNormaliseAdjacency:

    def test_shape_preserved(self):
        adj  = np.random.rand(5, 5)
        norm = normalise_adjacency(adj)
        assert norm.shape == (5, 5)

    def test_symmetric_input(self):
        """Symmetric adjacency should remain symmetric after normalisation."""
        adj  = np.random.rand(4, 4)
        adj  = (adj + adj.T) / 2
        norm = normalise_adjacency(adj)
        assert np.allclose(norm, norm.T, atol=1e-6)


class TestBandPowers:

    def test_output_shape(self):
        data   = np.random.randn(23, 1280)
        powers = extract_band_powers(data, sfreq=256.0)
        assert powers.shape == (23, 5), f"Expected (23,5), got {powers.shape}"

    def test_non_negative(self):
        data   = np.random.randn(5, 1280)
        powers = extract_band_powers(data, sfreq=256.0)
        assert powers.min() >= 0, "Band powers must be non-negative"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
